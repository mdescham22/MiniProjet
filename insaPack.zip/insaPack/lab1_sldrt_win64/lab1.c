/*
 * lab1.c
 *
 * Classroom License -- for classroom instructional use only.  Not for
 * government, commercial, academic research, or other organizational use.
 *
 * Code generation for model "lab1".
 *
 * Model version              : 1.27
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Tue Apr 11 15:03:37 2023
 *
 * Target selection: sldrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "lab1.h"
#include "lab1_private.h"
#include "lab1_dt.h"

/* options for Simulink Desktop Real-Time board 0 */
static double SLDRTBoardOptions0[] = {
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
};

/* list of Simulink Desktop Real-Time timers */
const int SLDRTTimerCount = 1;
const double SLDRTTimers[2] = {
  0.027750000000000004, 0.0,
};

/* list of Simulink Desktop Real-Time boards */
const int SLDRTBoardCount = 1;
SLDRTBOARD SLDRTBoards[1] = {
  { "National_Instruments/PCI-6024E", 4294967295U, 6, SLDRTBoardOptions0 },
};

/* Block signals (default storage) */
B_lab1_T lab1_B;

/* Block states (default storage) */
DW_lab1_T lab1_DW;

/* Real-time model */
RT_MODEL_lab1_T lab1_M_;
RT_MODEL_lab1_T *const lab1_M = &lab1_M_;

/* Model output function */
void lab1_output(void)
{
  /* FromWorkspace: '<Root>/From Workspace' */
  {
    real_T *pDataValues = (real_T *) lab1_DW.FromWorkspace_PWORK.DataPtr;
    real_T *pTimeValues = (real_T *) lab1_DW.FromWorkspace_PWORK.TimePtr;
    int_T currTimeIndex = lab1_DW.FromWorkspace_IWORK.PrevIndex;
    real_T t = lab1_M->Timing.t[0];

    /* Get index */
    if (t <= pTimeValues[0]) {
      currTimeIndex = 0;
    } else if (t >= pTimeValues[496]) {
      currTimeIndex = 495;
    } else {
      if (t < pTimeValues[currTimeIndex]) {
        while (t < pTimeValues[currTimeIndex]) {
          currTimeIndex--;
        }
      } else {
        while (t >= pTimeValues[currTimeIndex + 1]) {
          currTimeIndex++;
        }
      }
    }

    lab1_DW.FromWorkspace_IWORK.PrevIndex = currTimeIndex;

    /* Post output */
    {
      real_T t1 = pTimeValues[currTimeIndex];
      real_T t2 = pTimeValues[currTimeIndex + 1];
      if (t1 == t2) {
        if (t < t1) {
          lab1_B.FromWorkspace = pDataValues[currTimeIndex];
        } else {
          lab1_B.FromWorkspace = pDataValues[currTimeIndex + 1];
        }
      } else {
        real_T f1 = (t2 - t) / (t2 - t1);
        real_T f2 = 1.0 - f1;
        real_T d1;
        real_T d2;
        int_T TimeIndex= currTimeIndex;
        d1 = pDataValues[TimeIndex];
        d2 = pDataValues[TimeIndex + 1];
        lab1_B.FromWorkspace = (real_T) rtInterpolate(d1, d2, f1, f2);
        pDataValues += 497;
      }
    }
  }

  /* S-Function (sldrtao): '<Root>/Analog Output' */
  /* S-Function Block: <Root>/Analog Output */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE) lab1_P.AnalogOutput_RangeMode;
      parm.rangeidx = lab1_P.AnalogOutput_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1, &lab1_P.AnalogOutput_Channels,
                     ((real_T*) (&lab1_B.FromWorkspace)), &parm);
    }
  }

  /* S-Function (sldrtai): '<Root>/Analog Input' */
  /* S-Function Block: <Root>/Analog Input */
  {
    ANALOGIOPARM parm;
    parm.mode = (RANGEMODE) lab1_P.AnalogInput_RangeMode;
    parm.rangeidx = lab1_P.AnalogInput_VoltRange;
    RTBIO_DriverIO(0, ANALOGINPUT, IOREAD, 1, &lab1_P.AnalogInput_Channels,
                   &lab1_B.AnalogInput, &parm);
  }

  /* ToAsyncQueueBlock generated from: '<Root>/Analog Input' */
  {
    {
      double time = lab1_M->Timing.t[0];
      void *pData = (void *)&lab1_B.AnalogInput;
      int32_T size = 1*sizeof(real_T);
      sendToAsyncQueueTgtAppSvc(3205161553U, time, pData, size);
    }
  }

  /* ToAsyncQueueBlock generated from: '<Root>/From Workspace' */
  {
    {
      double time = lab1_M->Timing.t[0];
      void *pData = (void *)&lab1_B.FromWorkspace;
      int32_T size = 1*sizeof(real_T);
      sendToAsyncQueueTgtAppSvc(2804354570U, time, pData, size);
    }
  }
}

/* Model update function */
void lab1_update(void)
{
  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++lab1_M->Timing.clockTick0)) {
    ++lab1_M->Timing.clockTickH0;
  }

  lab1_M->Timing.t[0] = lab1_M->Timing.clockTick0 * lab1_M->Timing.stepSize0 +
    lab1_M->Timing.clockTickH0 * lab1_M->Timing.stepSize0 * 4294967296.0;
}

/* Model initialize function */
void lab1_initialize(void)
{
  /* Start for FromWorkspace: '<Root>/From Workspace' */
  {
    static real_T pTimeValues0[] = { 0.0, 0.027750000000000004,
      0.055500000000000008, 0.083250000000000018, 0.11100000000000002, 0.13875,
      0.16650000000000004, 0.19425000000000003, 0.22200000000000003,
      0.24975000000000003, 0.2775, 0.30525, 0.33300000000000007,
      0.36075000000000007, 0.38850000000000007, 0.41625000000000006,
      0.44400000000000006, 0.47175000000000006, 0.49950000000000006,
      0.52725000000000011, 0.555, 0.5827500000000001, 0.6105, 0.6382500000000001,
      0.66600000000000015, 0.69375000000000009, 0.72150000000000014,
      0.74925000000000008, 0.77700000000000014, 0.80475000000000008,
      0.83250000000000013, 0.86025000000000007, 0.88800000000000012,
      0.91575000000000017, 0.94350000000000012, 0.97125000000000017,
      0.99900000000000011, 1.02675, 1.0545000000000002, 1.0822500000000002, 1.11,
      1.1377500000000003, 1.1655000000000002, 1.1932500000000001, 1.221,
      1.2487500000000002, 1.2765000000000002, 1.3042500000000001,
      1.3320000000000003, 1.3597500000000002, 1.3875000000000002,
      1.4152500000000001, 1.4430000000000003, 1.4707500000000002,
      1.4985000000000002, 1.52625, 1.5540000000000003, 1.5817500000000002,
      1.6095000000000002, 1.6372500000000003, 1.6650000000000003,
      1.6927500000000002, 1.7205000000000001, 1.7482500000000003,
      1.7760000000000002, 1.8037500000000002, 1.8315000000000003,
      1.8592500000000003, 1.8870000000000002, 1.9147500000000002,
      1.9425000000000003, 1.9702500000000003, 1.9980000000000002,
      2.0257500000000004, 2.0535, 2.0812500000000003, 2.1090000000000004,
      2.13675, 2.1645000000000003, 2.1922500000000005, 2.22, 2.2477500000000004,
      2.2755000000000005, 2.3032500000000002, 2.3310000000000004, 2.35875,
      2.3865000000000003, 2.4142500000000005, 2.442, 2.4697500000000003,
      2.4975000000000005, 2.52525, 2.5530000000000004, 2.5807500000000005,
      2.6085000000000003, 2.6362500000000004, 2.6640000000000006,
      2.6917500000000003, 2.7195000000000005, 2.74725, 2.7750000000000004,
      2.8027500000000005, 2.8305000000000002, 2.8582500000000004,
      2.8860000000000006, 2.9137500000000003, 2.9415000000000004,
      2.9692500000000006, 2.9970000000000003, 3.0247500000000005, 3.0525,
      3.0802500000000004, 3.1080000000000005, 3.1357500000000003,
      3.1635000000000004, 3.1912500000000006, 3.2190000000000003,
      3.2467500000000005, 3.2745000000000006, 3.3022500000000004,
      3.3300000000000005, 3.3577500000000007, 3.3855000000000004,
      3.4132500000000006, 3.4410000000000003, 3.4687500000000004,
      3.4965000000000006, 3.5242500000000003, 3.5520000000000005,
      3.5797500000000007, 3.6075000000000004, 3.6352500000000005,
      3.6630000000000007, 3.6907500000000004, 3.7185000000000006,
      3.7462500000000003, 3.7740000000000005, 3.8017500000000006,
      3.8295000000000003, 3.8572500000000005, 3.8850000000000007,
      3.9127500000000004, 3.9405000000000006, 3.9682500000000007,
      3.9960000000000004, 4.0237500000000006, 4.0515000000000008,
      4.0792500000000009, 4.107, 4.13475, 4.1625000000000005, 4.1902500000000007,
      4.2180000000000009, 4.245750000000001, 4.2735, 4.3012500000000005,
      4.3290000000000006, 4.3567500000000008, 4.384500000000001, 4.41225, 4.44,
      4.4677500000000006, 4.4955000000000007, 4.5232500000000009,
      4.551000000000001, 4.57875, 4.6065000000000005, 4.6342500000000006,
      4.6620000000000008, 4.689750000000001, 4.7175, 4.74525, 4.7730000000000006,
      4.8007500000000007, 4.8285000000000009, 4.8562500000000011, 4.884,
      4.9117500000000005, 4.9395000000000007, 4.9672500000000008,
      4.995000000000001, 5.02275, 5.0505, 5.0782500000000006, 5.1060000000000008,
      5.1337500000000009, 5.1615000000000011, 5.18925, 5.2170000000000005,
      5.2447500000000007, 5.2725000000000009, 5.300250000000001,
      5.3280000000000012, 5.3557500000000005, 5.3835000000000006,
      5.4112500000000008, 5.4390000000000009, 5.4667500000000011, 5.4945,
      5.5222500000000005, 5.5500000000000007, 5.5777500000000009,
      5.605500000000001, 5.6332500000000012, 5.6610000000000005,
      5.6887500000000006, 5.7165000000000008, 5.744250000000001,
      5.7720000000000011, 5.79975, 5.8275000000000006, 5.8552500000000007,
      5.8830000000000009, 5.9107500000000011, 5.9385000000000012,
      5.9662500000000005, 5.9940000000000007, 6.0217500000000008,
      6.049500000000001, 6.0772500000000012, 6.105, 6.1327500000000006,
      6.1605000000000008, 6.1882500000000009, 6.2160000000000011,
      6.2437500000000012, 6.2715000000000005, 6.2992500000000007,
      6.3270000000000008, 6.354750000000001, 6.3825000000000012,
      6.4102500000000004, 6.4380000000000006, 6.4657500000000008,
      6.4935000000000009, 6.5212500000000011, 6.5490000000000013,
      6.5767500000000005, 6.6045000000000007, 6.6322500000000009,
      6.660000000000001, 6.6877500000000012, 6.7155000000000014,
      6.7432500000000006, 6.7710000000000008, 6.798750000000001,
      6.8265000000000011, 6.8542500000000013, 6.8820000000000006, 6.90975,
      6.9375, 6.96525, 6.993, 7.0207500000000005, 7.0485, 7.07625, 7.104,
      7.13175, 7.1595, 7.1872500000000006, 7.215, 7.24275, 7.2705, 7.29825,
      7.3260000000000005, 7.3537500000000007, 7.3815, 7.40925, 7.437, 7.46475,
      7.4925000000000006, 7.52025, 7.548, 7.57575, 7.6035, 7.6312500000000005,
      7.6590000000000007, 7.68675, 7.7145, 7.74225, 7.7700000000000005,
      7.7977500000000006, 7.8255, 7.85325, 7.881, 7.90875, 7.9365000000000006,
      7.9642500000000007, 7.992, 8.01975, 8.0475, 8.07525, 8.1030000000000015,
      8.130749999999999, 8.1585, 8.1862500000000011, 8.214, 8.24175, 8.2695,
      8.29725, 8.325, 8.35275, 8.3805000000000014, 8.40825, 8.436,
      8.463750000000001, 8.4915, 8.51925, 8.547, 8.5747500000000016, 8.6025,
      8.63025, 8.6580000000000013, 8.68575, 8.7135, 8.74125, 8.769, 8.79675,
      8.8245, 8.8522500000000015, 8.88, 8.90775, 8.9355000000000011, 8.96325,
      8.991, 9.01875, 9.0465000000000018, 9.07425, 9.102, 9.1297500000000014,
      9.1575, 9.18525, 9.213000000000001, 9.24075, 9.2685, 9.29625,
      9.3240000000000016, 9.3517500000000009, 9.3795, 9.4072500000000012, 9.435,
      9.46275, 9.4905, 9.51825, 9.546, 9.57375, 9.6015000000000015, 9.62925,
      9.657, 9.6847500000000011, 9.7125, 9.74025, 9.768, 9.79575,
      9.823500000000001, 9.85125, 9.8790000000000013, 9.90675, 9.9345,
      9.9622500000000009, 9.99, 10.017750000000001, 10.0455, 10.073250000000002,
      10.101, 10.12875, 10.156500000000001, 10.18425, 10.212, 10.23975, 10.2675,
      10.295250000000001, 10.323, 10.350750000000001, 10.3785, 10.40625,
      10.434000000000001, 10.46175, 10.4895, 10.51725, 10.545000000000002,
      10.572750000000001, 10.6005, 10.628250000000001, 10.656, 10.68375,
      10.711500000000001, 10.73925, 10.767000000000001, 10.79475,
      10.822500000000002, 10.85025, 10.878, 10.905750000000001, 10.9335,
      10.96125, 10.989, 11.016750000000002, 11.044500000000001, 11.07225,
      11.100000000000001, 11.12775, 11.1555, 11.183250000000001, 11.211,
      11.238750000000001, 11.2665, 11.294250000000002, 11.322000000000001,
      11.34975, 11.377500000000001, 11.40525, 11.433, 11.46075, 11.4885,
      11.516250000000001, 11.544, 11.571750000000002, 11.5995, 11.62725,
      11.655000000000001, 11.68275, 11.710500000000001, 11.73825,
      11.766000000000002, 11.793750000000001, 11.8215, 11.849250000000001,
      11.877, 11.90475, 11.932500000000001, 11.96025, 11.988000000000001,
      12.01575, 12.043500000000002, 12.071250000000001, 12.099,
      12.126750000000001, 12.1545, 12.182250000000002, 12.21, 12.237750000000002,
      12.265500000000001, 12.29325, 12.321000000000002, 12.34875, 12.3765,
      12.404250000000001, 12.432, 12.459750000000001, 12.4875,
      12.515250000000002, 12.543000000000001, 12.57075, 12.598500000000001,
      12.62625, 12.654000000000002, 12.681750000000001, 12.7095,
      12.737250000000001, 12.765, 12.792750000000002, 12.820500000000001,
      12.84825, 12.876000000000001, 12.90375, 12.931500000000002, 12.95925,
      12.987000000000002, 13.014750000000001, 13.0425, 13.070250000000001,
      13.098, 13.125750000000002, 13.153500000000001, 13.18125,
      13.209000000000001, 13.23675, 13.264500000000002, 13.292250000000001,
      13.32, 13.347750000000001, 13.3755, 13.403250000000002, 13.431000000000001,
      13.458750000000002, 13.486500000000001, 13.51425, 13.542000000000002,
      13.56975, 13.597500000000002, 13.625250000000001, 13.653,
      13.680750000000002, 13.7085, 13.736250000000002, 13.764000000000001 } ;

    static real_T pDataValues0[] = { 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4,
      3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 4.4, 4.4, 4.4, 4.4, 3.4, 3.4, 3.4, 3.4,
      3.4, 3.4, 3.4, 3.4, 4.4, 4.4, 4.4, 4.4, 3.4, 3.4, 3.4, 3.4, 4.4, 4.4, 4.4,
      4.4, 4.4, 4.4, 4.4, 4.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 4.4, 4.4,
      4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4,
      4.4, 4.4, 4.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4,
      4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 3.4, 3.4, 3.4, 3.4, 4.4, 4.4, 4.4,
      4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 3.4, 3.4, 3.4, 3.4, 4.4, 4.4,
      4.4, 4.4, 3.4, 3.4, 3.4, 3.4, 4.4, 4.4, 4.4, 4.4, 3.4, 3.4, 3.4, 3.4, 3.4,
      3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 4.4, 4.4, 4.4, 4.4,
      3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 4.4, 4.4, 4.4, 4.4, 3.4, 3.4, 3.4,
      3.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4,
      3.4, 3.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4,
      4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4,
      3.4, 3.4, 3.4, 3.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 3.4, 3.4, 3.4,
      3.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 3.4, 3.4,
      3.4, 3.4, 4.4, 4.4, 4.4, 4.4, 3.4, 3.4, 3.4, 3.4, 4.4, 4.4, 4.4, 4.4, 3.4,
      3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4,
      4.4, 4.4, 4.4, 4.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 4.4, 4.4, 4.4,
      4.4, 3.4, 3.4, 3.4, 3.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 3.4, 3.4,
      3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4,
      4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 3.4, 3.4, 3.4, 3.4,
      3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4,
      4.4, 3.4, 3.4, 3.4, 3.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4,
      4.4, 4.4, 3.4, 3.4, 3.4, 3.4, 4.4, 4.4, 4.4, 4.4, 3.4, 3.4, 3.4, 3.4, 4.4,
      4.4, 4.4, 4.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4,
      3.4, 3.4, 3.4, 3.4, 4.4, 4.4, 4.4, 4.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4,
      3.4, 4.4, 4.4, 4.4, 4.4, 3.4, 3.4, 3.4, 3.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4,
      4.4, 4.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 4.4, 4.4, 4.4, 4.4, 4.4,
      4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4,
      3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 3.4, 4.4, 4.4, 4.4,
      4.4, 4.4, 4.4, 4.4, 4.4, 3.4, 3.4, 3.4, 3.4, 4.4, 4.4, 4.4, 4.4, 4.4, 4.4,
      4.4, 4.4, 4.4, 4.4, 4.4, 4.4, 3.4, 3.4, 3.4, 3.4, 4.4, 4.4, 4.4, 4.4, 3.4,
      3.4, 3.4, 3.4, 4.4, 4.4, 4.4, 4.4, 3.4 } ;

    lab1_DW.FromWorkspace_PWORK.TimePtr = (void *) pTimeValues0;
    lab1_DW.FromWorkspace_PWORK.DataPtr = (void *) pDataValues0;
    lab1_DW.FromWorkspace_IWORK.PrevIndex = 0;
  }

  /* Start for S-Function (sldrtao): '<Root>/Analog Output' */

  /* S-Function Block: <Root>/Analog Output */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE) lab1_P.AnalogOutput_RangeMode;
      parm.rangeidx = lab1_P.AnalogOutput_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1, &lab1_P.AnalogOutput_Channels,
                     &lab1_P.AnalogOutput_InitialValue, &parm);
    }
  }
}

/* Model terminate function */
void lab1_terminate(void)
{
  /* Terminate for S-Function (sldrtao): '<Root>/Analog Output' */

  /* S-Function Block: <Root>/Analog Output */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE) lab1_P.AnalogOutput_RangeMode;
      parm.rangeidx = lab1_P.AnalogOutput_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1, &lab1_P.AnalogOutput_Channels,
                     &lab1_P.AnalogOutput_FinalValue, &parm);
    }
  }
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/
void MdlOutputs(int_T tid)
{
  lab1_output();
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  lab1_update();
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  lab1_initialize();
}

void MdlTerminate(void)
{
  lab1_terminate();
}

/* Registration function */
RT_MODEL_lab1_T *lab1(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)lab1_M, 0,
                sizeof(RT_MODEL_lab1_T));

  /* Initialize timing info */
  {
    int_T *mdlTsMap = lab1_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    lab1_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    lab1_M->Timing.sampleTimes = (&lab1_M->Timing.sampleTimesArray[0]);
    lab1_M->Timing.offsetTimes = (&lab1_M->Timing.offsetTimesArray[0]);

    /* task periods */
    lab1_M->Timing.sampleTimes[0] = (0.027750000000000004);

    /* task offsets */
    lab1_M->Timing.offsetTimes[0] = (0.0);
  }

  rtmSetTPtr(lab1_M, &lab1_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = lab1_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    lab1_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(lab1_M, 13.014750000000001);
  lab1_M->Timing.stepSize0 = 0.027750000000000004;

  /* External mode info */
  lab1_M->Sizes.checksums[0] = (1983457429U);
  lab1_M->Sizes.checksums[1] = (750169268U);
  lab1_M->Sizes.checksums[2] = (2331588128U);
  lab1_M->Sizes.checksums[3] = (934279310U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[1];
    lab1_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(lab1_M->extModeInfo,
      &lab1_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(lab1_M->extModeInfo, lab1_M->Sizes.checksums);
    rteiSetTPtr(lab1_M->extModeInfo, rtmGetTPtr(lab1_M));
  }

  lab1_M->solverInfoPtr = (&lab1_M->solverInfo);
  lab1_M->Timing.stepSize = (0.027750000000000004);
  rtsiSetFixedStepSize(&lab1_M->solverInfo, 0.027750000000000004);
  rtsiSetSolverMode(&lab1_M->solverInfo, SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  lab1_M->blockIO = ((void *) &lab1_B);
  (void) memset(((void *) &lab1_B), 0,
                sizeof(B_lab1_T));

  /* parameters */
  lab1_M->defaultParam = ((real_T *)&lab1_P);

  /* states (dwork) */
  lab1_M->dwork = ((void *) &lab1_DW);
  (void) memset((void *)&lab1_DW, 0,
                sizeof(DW_lab1_T));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    lab1_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 14;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.PTransTable = &rtPTransTable;
  }

  /* Initialize Sizes */
  lab1_M->Sizes.numContStates = (0);   /* Number of continuous states */
  lab1_M->Sizes.numY = (0);            /* Number of model outputs */
  lab1_M->Sizes.numU = (0);            /* Number of model inputs */
  lab1_M->Sizes.sysDirFeedThru = (0);  /* The model is not direct feedthrough */
  lab1_M->Sizes.numSampTimes = (1);    /* Number of sample times */
  lab1_M->Sizes.numBlocks = (6);       /* Number of blocks */
  lab1_M->Sizes.numBlockIO = (2);      /* Number of block outputs */
  lab1_M->Sizes.numBlockPrms = (12);   /* Sum of parameter "widths" */
  return lab1_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/

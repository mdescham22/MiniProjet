/*
 * Correcteur.c
 *
 * Classroom License -- for classroom instructional use only.  Not for
 * government, commercial, academic research, or other organizational use.
 *
 * Code generation for model "Correcteur".
 *
 * Model version              : 1.85
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Thu May 11 17:06:42 2023
 *
 * Target selection: sldrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Correcteur.h"
#include "Correcteur_private.h"
#include "Correcteur_dt.h"

/* list of Simulink Desktop Real-Time timers */
const int SLDRTTimerCount = 1;
const double SLDRTTimers[2] = {
  0.01, 0.0,
};

/* Block signals (default storage) */
B_Correcteur_T Correcteur_B;

/* Continuous states */
X_Correcteur_T Correcteur_X;

/* Block states (default storage) */
DW_Correcteur_T Correcteur_DW;

/* Real-time model */
RT_MODEL_Correcteur_T Correcteur_M_;
RT_MODEL_Correcteur_T *const Correcteur_M = &Correcteur_M_;

/*
 * This function updates continuous states using the ODE3 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  /* Solver Matrices */
  static const real_T rt_ODE3_A[3] = {
    1.0/2.0, 3.0/4.0, 1.0
  };

  static const real_T rt_ODE3_B[3][3] = {
    { 1.0/2.0, 0.0, 0.0 },

    { 0.0, 3.0/4.0, 0.0 },

    { 2.0/9.0, 1.0/3.0, 4.0/9.0 }
  };

  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE3_IntgData *id = (ODE3_IntgData *)rtsiGetSolverData(si);
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T hB[3];
  int_T i;
  int_T nXc = 4;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  /* Save the state values at time t in y, we'll use x as ynew. */
  (void) memcpy(y, x,
                (uint_T)nXc*sizeof(real_T));

  /* Assumes that rtsiSetT and ModelOutputs are up-to-date */
  /* f0 = f(t,y) */
  rtsiSetdX(si, f0);
  Correcteur_derivatives();

  /* f(:,2) = feval(odefile, t + hA(1), y + f*hB(:,1), args(:)(*)); */
  hB[0] = h * rt_ODE3_B[0][0];
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[0]);
  rtsiSetdX(si, f1);
  Correcteur_output();
  Correcteur_derivatives();

  /* f(:,3) = feval(odefile, t + hA(2), y + f*hB(:,2), args(:)(*)); */
  for (i = 0; i <= 1; i++) {
    hB[i] = h * rt_ODE3_B[1][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[1]);
  rtsiSetdX(si, f2);
  Correcteur_output();
  Correcteur_derivatives();

  /* tnew = t + hA(3);
     ynew = y + f*hB(:,3); */
  for (i = 0; i <= 2; i++) {
    hB[i] = h * rt_ODE3_B[2][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2]);
  }

  rtsiSetT(si, tnew);
  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/* Model output function */
void Correcteur_output(void)
{
  if (rtmIsMajorTimeStep(Correcteur_M)) {
    /* set solver stop time */
    if (!(Correcteur_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&Correcteur_M->solverInfo,
                            ((Correcteur_M->Timing.clockTickH0 + 1) *
        Correcteur_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&Correcteur_M->solverInfo,
                            ((Correcteur_M->Timing.clockTick0 + 1) *
        Correcteur_M->Timing.stepSize0 + Correcteur_M->Timing.clockTickH0 *
        Correcteur_M->Timing.stepSize0 * 4294967296.0));
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(Correcteur_M)) {
    Correcteur_M->Timing.t[0] = rtsiGetT(&Correcteur_M->solverInfo);
  }

  /* Step: '<Root>/Step' */
  if (Correcteur_M->Timing.t[0] < Correcteur_P.Step_Time) {
    Correcteur_B.Step = Correcteur_P.Step_Y0;
  } else {
    Correcteur_B.Step = Correcteur_P.Step_YFinal;
  }

  /* End of Step: '<Root>/Step' */
  if (rtmIsMajorTimeStep(Correcteur_M)) {
    /* ToAsyncQueueBlock generated from: '<Root>/Step' */
    if (rtmIsMajorTimeStep(Correcteur_M)) {
      {
        double time = Correcteur_M->Timing.t[1];
        void *pData = (void *)&Correcteur_B.Step;
        int32_T size = 1*sizeof(real_T);
        sendToAsyncQueueTgtAppSvc(1991514008U, time, pData, size);
      }
    }
  }

  /* TransferFcn: '<Root>/Transfer Fcn' */
  Correcteur_B.TransferFcn = 0.0;
  Correcteur_B.TransferFcn += Correcteur_P.TransferFcn_C[0] *
    Correcteur_X.TransferFcn_CSTATE[0];
  Correcteur_B.TransferFcn += Correcteur_P.TransferFcn_C[1] *
    Correcteur_X.TransferFcn_CSTATE[1];
  Correcteur_B.TransferFcn += Correcteur_P.TransferFcn_C[2] *
    Correcteur_X.TransferFcn_CSTATE[2];
  Correcteur_B.TransferFcn += Correcteur_P.TransferFcn_C[3] *
    Correcteur_X.TransferFcn_CSTATE[3];
  if (rtmIsMajorTimeStep(Correcteur_M)) {
    /* ToAsyncQueueBlock generated from: '<Root>/Transfer Fcn' */
    if (rtmIsMajorTimeStep(Correcteur_M)) {
      {
        double time = Correcteur_M->Timing.t[1];
        void *pData = (void *)&Correcteur_B.TransferFcn;
        int32_T size = 1*sizeof(real_T);
        sendToAsyncQueueTgtAppSvc(4044699094U, time, pData, size);
      }
    }
  }

  /* Gain: '<Root>/Gain' incorporates:
   *  Sum: '<Root>/Sum'
   */
  Correcteur_B.Gain = (Correcteur_B.Step - Correcteur_B.TransferFcn) *
    Correcteur_P.Gain_Gain;
}

/* Model update function */
void Correcteur_update(void)
{
  if (rtmIsMajorTimeStep(Correcteur_M)) {
    rt_ertODEUpdateContinuousStates(&Correcteur_M->solverInfo);
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++Correcteur_M->Timing.clockTick0)) {
    ++Correcteur_M->Timing.clockTickH0;
  }

  Correcteur_M->Timing.t[0] = rtsiGetSolverStopTime(&Correcteur_M->solverInfo);

  {
    /* Update absolute timer for sample time: [0.01s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick1"
     * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++Correcteur_M->Timing.clockTick1)) {
      ++Correcteur_M->Timing.clockTickH1;
    }

    Correcteur_M->Timing.t[1] = Correcteur_M->Timing.clockTick1 *
      Correcteur_M->Timing.stepSize1 + Correcteur_M->Timing.clockTickH1 *
      Correcteur_M->Timing.stepSize1 * 4294967296.0;
  }
}

/* Derivatives for root system: '<Root>' */
void Correcteur_derivatives(void)
{
  XDot_Correcteur_T *_rtXdot;
  _rtXdot = ((XDot_Correcteur_T *) Correcteur_M->derivs);

  /* Derivatives for TransferFcn: '<Root>/Transfer Fcn' */
  _rtXdot->TransferFcn_CSTATE[0] = 0.0;
  _rtXdot->TransferFcn_CSTATE[0] += Correcteur_P.TransferFcn_A[0] *
    Correcteur_X.TransferFcn_CSTATE[0];
  _rtXdot->TransferFcn_CSTATE[1] = 0.0;
  _rtXdot->TransferFcn_CSTATE[0] += Correcteur_P.TransferFcn_A[1] *
    Correcteur_X.TransferFcn_CSTATE[1];
  _rtXdot->TransferFcn_CSTATE[2] = 0.0;
  _rtXdot->TransferFcn_CSTATE[0] += Correcteur_P.TransferFcn_A[2] *
    Correcteur_X.TransferFcn_CSTATE[2];
  _rtXdot->TransferFcn_CSTATE[3] = 0.0;
  _rtXdot->TransferFcn_CSTATE[0] += Correcteur_P.TransferFcn_A[3] *
    Correcteur_X.TransferFcn_CSTATE[3];
  _rtXdot->TransferFcn_CSTATE[1] += Correcteur_X.TransferFcn_CSTATE[0];
  _rtXdot->TransferFcn_CSTATE[2] += Correcteur_X.TransferFcn_CSTATE[1];
  _rtXdot->TransferFcn_CSTATE[3] += Correcteur_X.TransferFcn_CSTATE[2];
  _rtXdot->TransferFcn_CSTATE[0] += Correcteur_B.Gain;
}

/* Model initialize function */
void Correcteur_initialize(void)
{
  /* InitializeConditions for TransferFcn: '<Root>/Transfer Fcn' */
  Correcteur_X.TransferFcn_CSTATE[0] = 0.0;
  Correcteur_X.TransferFcn_CSTATE[1] = 0.0;
  Correcteur_X.TransferFcn_CSTATE[2] = 0.0;
  Correcteur_X.TransferFcn_CSTATE[3] = 0.0;
}

/* Model terminate function */
void Correcteur_terminate(void)
{
  /* (no terminate code required) */
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/

/* Solver interface called by GRT_Main */
#ifndef USE_GENERATED_SOLVER

void rt_ODECreateIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEDestroyIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEUpdateContinuousStates(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

#endif

void MdlOutputs(int_T tid)
{
  Correcteur_output();
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  Correcteur_update();
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  Correcteur_initialize();
}

void MdlTerminate(void)
{
  Correcteur_terminate();
}

/* Registration function */
RT_MODEL_Correcteur_T *Correcteur(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)Correcteur_M, 0,
                sizeof(RT_MODEL_Correcteur_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&Correcteur_M->solverInfo,
                          &Correcteur_M->Timing.simTimeStep);
    rtsiSetTPtr(&Correcteur_M->solverInfo, &rtmGetTPtr(Correcteur_M));
    rtsiSetStepSizePtr(&Correcteur_M->solverInfo,
                       &Correcteur_M->Timing.stepSize0);
    rtsiSetdXPtr(&Correcteur_M->solverInfo, &Correcteur_M->derivs);
    rtsiSetContStatesPtr(&Correcteur_M->solverInfo, (real_T **)
                         &Correcteur_M->contStates);
    rtsiSetNumContStatesPtr(&Correcteur_M->solverInfo,
      &Correcteur_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&Correcteur_M->solverInfo,
      &Correcteur_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&Correcteur_M->solverInfo,
      &Correcteur_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&Correcteur_M->solverInfo,
      &Correcteur_M->periodicContStateRanges);
    rtsiSetErrorStatusPtr(&Correcteur_M->solverInfo, (&rtmGetErrorStatus
      (Correcteur_M)));
    rtsiSetRTModelPtr(&Correcteur_M->solverInfo, Correcteur_M);
  }

  rtsiSetSimTimeStep(&Correcteur_M->solverInfo, MAJOR_TIME_STEP);
  Correcteur_M->intgData.y = Correcteur_M->odeY;
  Correcteur_M->intgData.f[0] = Correcteur_M->odeF[0];
  Correcteur_M->intgData.f[1] = Correcteur_M->odeF[1];
  Correcteur_M->intgData.f[2] = Correcteur_M->odeF[2];
  Correcteur_M->contStates = ((real_T *) &Correcteur_X);
  rtsiSetSolverData(&Correcteur_M->solverInfo, (void *)&Correcteur_M->intgData);
  rtsiSetSolverName(&Correcteur_M->solverInfo,"ode3");

  /* Initialize timing info */
  {
    int_T *mdlTsMap = Correcteur_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    mdlTsMap[1] = 1;
    Correcteur_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    Correcteur_M->Timing.sampleTimes = (&Correcteur_M->Timing.sampleTimesArray[0]);
    Correcteur_M->Timing.offsetTimes = (&Correcteur_M->Timing.offsetTimesArray[0]);

    /* task periods */
    Correcteur_M->Timing.sampleTimes[0] = (0.0);
    Correcteur_M->Timing.sampleTimes[1] = (0.01);

    /* task offsets */
    Correcteur_M->Timing.offsetTimes[0] = (0.0);
    Correcteur_M->Timing.offsetTimes[1] = (0.0);
  }

  rtmSetTPtr(Correcteur_M, &Correcteur_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = Correcteur_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    mdlSampleHits[1] = 1;
    Correcteur_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(Correcteur_M, 32.0);
  Correcteur_M->Timing.stepSize0 = 0.01;
  Correcteur_M->Timing.stepSize1 = 0.01;

  /* External mode info */
  Correcteur_M->Sizes.checksums[0] = (2422651125U);
  Correcteur_M->Sizes.checksums[1] = (1259461218U);
  Correcteur_M->Sizes.checksums[2] = (4075474137U);
  Correcteur_M->Sizes.checksums[3] = (2122657083U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[1];
    Correcteur_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(Correcteur_M->extModeInfo,
      &Correcteur_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(Correcteur_M->extModeInfo, Correcteur_M->Sizes.checksums);
    rteiSetTPtr(Correcteur_M->extModeInfo, rtmGetTPtr(Correcteur_M));
  }

  Correcteur_M->solverInfoPtr = (&Correcteur_M->solverInfo);
  Correcteur_M->Timing.stepSize = (0.01);
  rtsiSetFixedStepSize(&Correcteur_M->solverInfo, 0.01);
  rtsiSetSolverMode(&Correcteur_M->solverInfo, SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  Correcteur_M->blockIO = ((void *) &Correcteur_B);
  (void) memset(((void *) &Correcteur_B), 0,
                sizeof(B_Correcteur_T));

  /* parameters */
  Correcteur_M->defaultParam = ((real_T *)&Correcteur_P);

  /* states (continuous) */
  {
    real_T *x = (real_T *) &Correcteur_X;
    Correcteur_M->contStates = (x);
    (void) memset((void *)&Correcteur_X, 0,
                  sizeof(X_Correcteur_T));
  }

  /* states (dwork) */
  Correcteur_M->dwork = ((void *) &Correcteur_DW);
  (void) memset((void *)&Correcteur_DW, 0,
                sizeof(DW_Correcteur_T));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    Correcteur_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 14;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.PTransTable = &rtPTransTable;
  }

  /* Initialize Sizes */
  Correcteur_M->Sizes.numContStates = (4);/* Number of continuous states */
  Correcteur_M->Sizes.numPeriodicContStates = (0);
                                      /* Number of periodic continuous states */
  Correcteur_M->Sizes.numY = (0);      /* Number of model outputs */
  Correcteur_M->Sizes.numU = (0);      /* Number of model inputs */
  Correcteur_M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  Correcteur_M->Sizes.numSampTimes = (2);/* Number of sample times */
  Correcteur_M->Sizes.numBlocks = (6); /* Number of blocks */
  Correcteur_M->Sizes.numBlockIO = (3);/* Number of block outputs */
  Correcteur_M->Sizes.numBlockPrms = (12);/* Sum of parameter "widths" */
  return Correcteur_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/

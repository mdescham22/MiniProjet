/*
 * CorrecteurPI_data.c
 *
 * Classroom License -- for classroom instructional use only.  Not for
 * government, commercial, academic research, or other organizational use.
 *
 * Code generation for model "CorrecteurPI".
 *
 * Model version              : 1.91
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Tue May 16 12:50:16 2023
 *
 * Target selection: sldrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "CorrecteurPI.h"
#include "CorrecteurPI_private.h"

/* Block parameters (default storage) */
P_CorrecteurPI_T CorrecteurPI_P = {
  /* Mask Parameter: PIDController_I
   * Referenced by: '<S30>/Integral Gain'
   */
  0.35806,

  /* Mask Parameter: PIDController_InitialConditionForIntegrator
   * Referenced by: '<S33>/Integrator'
   */
  0.0,

  /* Mask Parameter: PIDController_P
   * Referenced by: '<S38>/Proportional Gain'
   */
  1.0,

  /* Expression: 1
   * Referenced by: '<Root>/Step'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<Root>/Step'
   */
  0.0,

  /* Expression: 12
   * Referenced by: '<Root>/Step'
   */
  12.0,

  /* Computed Parameter: TransferFcn_A
   * Referenced by: '<Root>/Transfer Fcn'
   */
  { -2.4883474007570823, -20.803784495052888, -30.278617118953804,
    -85.039257647930526 },

  /* Computed Parameter: TransferFcn_C
   * Referenced by: '<Root>/Transfer Fcn'
   */
  { -2.1850008131796548, 9.40104403147184, -24.657190271519056,
    141.86392537564438 },

  /* Expression: 0.7
   * Referenced by: '<Root>/Gain'
   */
  0.7
};

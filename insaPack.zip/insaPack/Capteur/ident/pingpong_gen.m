
clear all, close all, clc;
% >> Graphic settings
%rng(12345)
insa.initGraphics

tau = 1.5;

% >> PRBS CASE (constructs u1,y1,y1n)
% Generate exciting signal
N       = 5;
Tr      = tau*3;
Ts      = Tr/20;
P       = 15;
Plot    = 1;
[u1,t1] = insa.prbs(Ts,N,Tr,P,Plot);
u1 = u1*0.1 + 3.83;
u1(1) = 6;
u1(2) = 6;
U = [t1.',u1];
% Apply to system to be identified
%y1      = lsim(G,u1,t1);
% Add noise
%y1n     = y1 .* (1 + lsim(Fn,randn(numel(y1),1),t1));
%figure
%subplot(221), hold on, axis tight
%plot(t1.',u1,'.-')
%plot(t1,y1n,'-')
%plot(out.y1.time,out.y1.data,'--')
%xlabel('Time [s]'); ylabel('Amplitude [.]'); title('PRBS')
%legend('$u(t_k)$','$y(t_k)+n(t_k)$','$y(t_k)$')

%save('signals','t1','u1','out.y1.data')

/*
 * CorrecteurPI.c
 *
 * Classroom License -- for classroom instructional use only.  Not for
 * government, commercial, academic research, or other organizational use.
 *
 * Code generation for model "CorrecteurPI".
 *
 * Model version              : 1.91
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Tue May 16 12:50:16 2023
 *
 * Target selection: sldrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "CorrecteurPI.h"
#include "CorrecteurPI_private.h"
#include "CorrecteurPI_dt.h"

/* list of Simulink Desktop Real-Time timers */
const int SLDRTTimerCount = 1;
const double SLDRTTimers[2] = {
  0.01, 0.0,
};

/* Block signals (default storage) */
B_CorrecteurPI_T CorrecteurPI_B;

/* Continuous states */
X_CorrecteurPI_T CorrecteurPI_X;

/* Block states (default storage) */
DW_CorrecteurPI_T CorrecteurPI_DW;

/* Real-time model */
RT_MODEL_CorrecteurPI_T CorrecteurPI_M_;
RT_MODEL_CorrecteurPI_T *const CorrecteurPI_M = &CorrecteurPI_M_;

/*
 * This function updates continuous states using the ODE3 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  /* Solver Matrices */
  static const real_T rt_ODE3_A[3] = {
    1.0/2.0, 3.0/4.0, 1.0
  };

  static const real_T rt_ODE3_B[3][3] = {
    { 1.0/2.0, 0.0, 0.0 },

    { 0.0, 3.0/4.0, 0.0 },

    { 2.0/9.0, 1.0/3.0, 4.0/9.0 }
  };

  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE3_IntgData *id = (ODE3_IntgData *)rtsiGetSolverData(si);
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T hB[3];
  int_T i;
  int_T nXc = 5;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  /* Save the state values at time t in y, we'll use x as ynew. */
  (void) memcpy(y, x,
                (uint_T)nXc*sizeof(real_T));

  /* Assumes that rtsiSetT and ModelOutputs are up-to-date */
  /* f0 = f(t,y) */
  rtsiSetdX(si, f0);
  CorrecteurPI_derivatives();

  /* f(:,2) = feval(odefile, t + hA(1), y + f*hB(:,1), args(:)(*)); */
  hB[0] = h * rt_ODE3_B[0][0];
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[0]);
  rtsiSetdX(si, f1);
  CorrecteurPI_output();
  CorrecteurPI_derivatives();

  /* f(:,3) = feval(odefile, t + hA(2), y + f*hB(:,2), args(:)(*)); */
  for (i = 0; i <= 1; i++) {
    hB[i] = h * rt_ODE3_B[1][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[1]);
  rtsiSetdX(si, f2);
  CorrecteurPI_output();
  CorrecteurPI_derivatives();

  /* tnew = t + hA(3);
     ynew = y + f*hB(:,3); */
  for (i = 0; i <= 2; i++) {
    hB[i] = h * rt_ODE3_B[2][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2]);
  }

  rtsiSetT(si, tnew);
  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/* Model output function */
void CorrecteurPI_output(void)
{
  real_T rtb_Gain;
  if (rtmIsMajorTimeStep(CorrecteurPI_M)) {
    /* set solver stop time */
    if (!(CorrecteurPI_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&CorrecteurPI_M->solverInfo,
                            ((CorrecteurPI_M->Timing.clockTickH0 + 1) *
        CorrecteurPI_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&CorrecteurPI_M->solverInfo,
                            ((CorrecteurPI_M->Timing.clockTick0 + 1) *
        CorrecteurPI_M->Timing.stepSize0 + CorrecteurPI_M->Timing.clockTickH0 *
        CorrecteurPI_M->Timing.stepSize0 * 4294967296.0));
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(CorrecteurPI_M)) {
    CorrecteurPI_M->Timing.t[0] = rtsiGetT(&CorrecteurPI_M->solverInfo);
  }

  /* Step: '<Root>/Step' */
  if (CorrecteurPI_M->Timing.t[0] < CorrecteurPI_P.Step_Time) {
    CorrecteurPI_B.Step = CorrecteurPI_P.Step_Y0;
  } else {
    CorrecteurPI_B.Step = CorrecteurPI_P.Step_YFinal;
  }

  /* End of Step: '<Root>/Step' */
  if (rtmIsMajorTimeStep(CorrecteurPI_M)) {
    /* ToAsyncQueueBlock generated from: '<Root>/Step' */
    if (rtmIsMajorTimeStep(CorrecteurPI_M)) {
      {
        double time = CorrecteurPI_M->Timing.t[1];
        void *pData = (void *)&CorrecteurPI_B.Step;
        int32_T size = 1*sizeof(real_T);
        sendToAsyncQueueTgtAppSvc(1890457704U, time, pData, size);
      }
    }
  }

  /* TransferFcn: '<Root>/Transfer Fcn' */
  CorrecteurPI_B.TransferFcn = 0.0;
  CorrecteurPI_B.TransferFcn += CorrecteurPI_P.TransferFcn_C[0] *
    CorrecteurPI_X.TransferFcn_CSTATE[0];
  CorrecteurPI_B.TransferFcn += CorrecteurPI_P.TransferFcn_C[1] *
    CorrecteurPI_X.TransferFcn_CSTATE[1];
  CorrecteurPI_B.TransferFcn += CorrecteurPI_P.TransferFcn_C[2] *
    CorrecteurPI_X.TransferFcn_CSTATE[2];
  CorrecteurPI_B.TransferFcn += CorrecteurPI_P.TransferFcn_C[3] *
    CorrecteurPI_X.TransferFcn_CSTATE[3];
  if (rtmIsMajorTimeStep(CorrecteurPI_M)) {
    /* ToAsyncQueueBlock generated from: '<Root>/Transfer Fcn' */
    if (rtmIsMajorTimeStep(CorrecteurPI_M)) {
      {
        double time = CorrecteurPI_M->Timing.t[1];
        void *pData = (void *)&CorrecteurPI_B.TransferFcn;
        int32_T size = 1*sizeof(real_T);
        sendToAsyncQueueTgtAppSvc(2549460413U, time, pData, size);
      }
    }
  }

  /* Gain: '<Root>/Gain' incorporates:
   *  Sum: '<Root>/Sum'
   */
  rtb_Gain = (CorrecteurPI_B.Step - CorrecteurPI_B.TransferFcn) *
    CorrecteurPI_P.Gain_Gain;

  /* Gain: '<S30>/Integral Gain' */
  CorrecteurPI_B.IntegralGain = CorrecteurPI_P.PIDController_I * rtb_Gain;

  /* Sum: '<S42>/Sum' incorporates:
   *  Gain: '<S38>/Proportional Gain'
   *  Integrator: '<S33>/Integrator'
   */
  CorrecteurPI_B.Sum = CorrecteurPI_P.PIDController_P * rtb_Gain +
    CorrecteurPI_X.Integrator_CSTATE;
}

/* Model update function */
void CorrecteurPI_update(void)
{
  if (rtmIsMajorTimeStep(CorrecteurPI_M)) {
    rt_ertODEUpdateContinuousStates(&CorrecteurPI_M->solverInfo);
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++CorrecteurPI_M->Timing.clockTick0)) {
    ++CorrecteurPI_M->Timing.clockTickH0;
  }

  CorrecteurPI_M->Timing.t[0] = rtsiGetSolverStopTime
    (&CorrecteurPI_M->solverInfo);

  {
    /* Update absolute timer for sample time: [0.01s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick1"
     * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++CorrecteurPI_M->Timing.clockTick1)) {
      ++CorrecteurPI_M->Timing.clockTickH1;
    }

    CorrecteurPI_M->Timing.t[1] = CorrecteurPI_M->Timing.clockTick1 *
      CorrecteurPI_M->Timing.stepSize1 + CorrecteurPI_M->Timing.clockTickH1 *
      CorrecteurPI_M->Timing.stepSize1 * 4294967296.0;
  }
}

/* Derivatives for root system: '<Root>' */
void CorrecteurPI_derivatives(void)
{
  XDot_CorrecteurPI_T *_rtXdot;
  _rtXdot = ((XDot_CorrecteurPI_T *) CorrecteurPI_M->derivs);

  /* Derivatives for TransferFcn: '<Root>/Transfer Fcn' */
  _rtXdot->TransferFcn_CSTATE[0] = 0.0;
  _rtXdot->TransferFcn_CSTATE[0] += CorrecteurPI_P.TransferFcn_A[0] *
    CorrecteurPI_X.TransferFcn_CSTATE[0];
  _rtXdot->TransferFcn_CSTATE[1] = 0.0;
  _rtXdot->TransferFcn_CSTATE[0] += CorrecteurPI_P.TransferFcn_A[1] *
    CorrecteurPI_X.TransferFcn_CSTATE[1];
  _rtXdot->TransferFcn_CSTATE[2] = 0.0;
  _rtXdot->TransferFcn_CSTATE[0] += CorrecteurPI_P.TransferFcn_A[2] *
    CorrecteurPI_X.TransferFcn_CSTATE[2];
  _rtXdot->TransferFcn_CSTATE[3] = 0.0;
  _rtXdot->TransferFcn_CSTATE[0] += CorrecteurPI_P.TransferFcn_A[3] *
    CorrecteurPI_X.TransferFcn_CSTATE[3];
  _rtXdot->TransferFcn_CSTATE[1] += CorrecteurPI_X.TransferFcn_CSTATE[0];
  _rtXdot->TransferFcn_CSTATE[2] += CorrecteurPI_X.TransferFcn_CSTATE[1];
  _rtXdot->TransferFcn_CSTATE[3] += CorrecteurPI_X.TransferFcn_CSTATE[2];
  _rtXdot->TransferFcn_CSTATE[0] += CorrecteurPI_B.Sum;

  /* Derivatives for Integrator: '<S33>/Integrator' */
  _rtXdot->Integrator_CSTATE = CorrecteurPI_B.IntegralGain;
}

/* Model initialize function */
void CorrecteurPI_initialize(void)
{
  /* InitializeConditions for TransferFcn: '<Root>/Transfer Fcn' */
  CorrecteurPI_X.TransferFcn_CSTATE[0] = 0.0;
  CorrecteurPI_X.TransferFcn_CSTATE[1] = 0.0;
  CorrecteurPI_X.TransferFcn_CSTATE[2] = 0.0;
  CorrecteurPI_X.TransferFcn_CSTATE[3] = 0.0;

  /* InitializeConditions for Integrator: '<S33>/Integrator' */
  CorrecteurPI_X.Integrator_CSTATE =
    CorrecteurPI_P.PIDController_InitialConditionForIntegrator;
}

/* Model terminate function */
void CorrecteurPI_terminate(void)
{
  /* (no terminate code required) */
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/

/* Solver interface called by GRT_Main */
#ifndef USE_GENERATED_SOLVER

void rt_ODECreateIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEDestroyIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEUpdateContinuousStates(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

#endif

void MdlOutputs(int_T tid)
{
  CorrecteurPI_output();
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  CorrecteurPI_update();
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  CorrecteurPI_initialize();
}

void MdlTerminate(void)
{
  CorrecteurPI_terminate();
}

/* Registration function */
RT_MODEL_CorrecteurPI_T *CorrecteurPI(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)CorrecteurPI_M, 0,
                sizeof(RT_MODEL_CorrecteurPI_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&CorrecteurPI_M->solverInfo,
                          &CorrecteurPI_M->Timing.simTimeStep);
    rtsiSetTPtr(&CorrecteurPI_M->solverInfo, &rtmGetTPtr(CorrecteurPI_M));
    rtsiSetStepSizePtr(&CorrecteurPI_M->solverInfo,
                       &CorrecteurPI_M->Timing.stepSize0);
    rtsiSetdXPtr(&CorrecteurPI_M->solverInfo, &CorrecteurPI_M->derivs);
    rtsiSetContStatesPtr(&CorrecteurPI_M->solverInfo, (real_T **)
                         &CorrecteurPI_M->contStates);
    rtsiSetNumContStatesPtr(&CorrecteurPI_M->solverInfo,
      &CorrecteurPI_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&CorrecteurPI_M->solverInfo,
      &CorrecteurPI_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&CorrecteurPI_M->solverInfo,
      &CorrecteurPI_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&CorrecteurPI_M->solverInfo,
      &CorrecteurPI_M->periodicContStateRanges);
    rtsiSetErrorStatusPtr(&CorrecteurPI_M->solverInfo, (&rtmGetErrorStatus
      (CorrecteurPI_M)));
    rtsiSetRTModelPtr(&CorrecteurPI_M->solverInfo, CorrecteurPI_M);
  }

  rtsiSetSimTimeStep(&CorrecteurPI_M->solverInfo, MAJOR_TIME_STEP);
  CorrecteurPI_M->intgData.y = CorrecteurPI_M->odeY;
  CorrecteurPI_M->intgData.f[0] = CorrecteurPI_M->odeF[0];
  CorrecteurPI_M->intgData.f[1] = CorrecteurPI_M->odeF[1];
  CorrecteurPI_M->intgData.f[2] = CorrecteurPI_M->odeF[2];
  CorrecteurPI_M->contStates = ((real_T *) &CorrecteurPI_X);
  rtsiSetSolverData(&CorrecteurPI_M->solverInfo, (void *)
                    &CorrecteurPI_M->intgData);
  rtsiSetSolverName(&CorrecteurPI_M->solverInfo,"ode3");

  /* Initialize timing info */
  {
    int_T *mdlTsMap = CorrecteurPI_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    mdlTsMap[1] = 1;
    CorrecteurPI_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    CorrecteurPI_M->Timing.sampleTimes =
      (&CorrecteurPI_M->Timing.sampleTimesArray[0]);
    CorrecteurPI_M->Timing.offsetTimes =
      (&CorrecteurPI_M->Timing.offsetTimesArray[0]);

    /* task periods */
    CorrecteurPI_M->Timing.sampleTimes[0] = (0.0);
    CorrecteurPI_M->Timing.sampleTimes[1] = (0.01);

    /* task offsets */
    CorrecteurPI_M->Timing.offsetTimes[0] = (0.0);
    CorrecteurPI_M->Timing.offsetTimes[1] = (0.0);
  }

  rtmSetTPtr(CorrecteurPI_M, &CorrecteurPI_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = CorrecteurPI_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    mdlSampleHits[1] = 1;
    CorrecteurPI_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(CorrecteurPI_M, 32.0);
  CorrecteurPI_M->Timing.stepSize0 = 0.01;
  CorrecteurPI_M->Timing.stepSize1 = 0.01;

  /* External mode info */
  CorrecteurPI_M->Sizes.checksums[0] = (3478488060U);
  CorrecteurPI_M->Sizes.checksums[1] = (1715508522U);
  CorrecteurPI_M->Sizes.checksums[2] = (3137969708U);
  CorrecteurPI_M->Sizes.checksums[3] = (805500203U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[1];
    CorrecteurPI_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(CorrecteurPI_M->extModeInfo,
      &CorrecteurPI_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(CorrecteurPI_M->extModeInfo,
                        CorrecteurPI_M->Sizes.checksums);
    rteiSetTPtr(CorrecteurPI_M->extModeInfo, rtmGetTPtr(CorrecteurPI_M));
  }

  CorrecteurPI_M->solverInfoPtr = (&CorrecteurPI_M->solverInfo);
  CorrecteurPI_M->Timing.stepSize = (0.01);
  rtsiSetFixedStepSize(&CorrecteurPI_M->solverInfo, 0.01);
  rtsiSetSolverMode(&CorrecteurPI_M->solverInfo, SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  CorrecteurPI_M->blockIO = ((void *) &CorrecteurPI_B);
  (void) memset(((void *) &CorrecteurPI_B), 0,
                sizeof(B_CorrecteurPI_T));

  /* parameters */
  CorrecteurPI_M->defaultParam = ((real_T *)&CorrecteurPI_P);

  /* states (continuous) */
  {
    real_T *x = (real_T *) &CorrecteurPI_X;
    CorrecteurPI_M->contStates = (x);
    (void) memset((void *)&CorrecteurPI_X, 0,
                  sizeof(X_CorrecteurPI_T));
  }

  /* states (dwork) */
  CorrecteurPI_M->dwork = ((void *) &CorrecteurPI_DW);
  (void) memset((void *)&CorrecteurPI_DW, 0,
                sizeof(DW_CorrecteurPI_T));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    CorrecteurPI_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 14;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.PTransTable = &rtPTransTable;
  }

  /* Initialize Sizes */
  CorrecteurPI_M->Sizes.numContStates = (5);/* Number of continuous states */
  CorrecteurPI_M->Sizes.numPeriodicContStates = (0);
                                      /* Number of periodic continuous states */
  CorrecteurPI_M->Sizes.numY = (0);    /* Number of model outputs */
  CorrecteurPI_M->Sizes.numU = (0);    /* Number of model inputs */
  CorrecteurPI_M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  CorrecteurPI_M->Sizes.numSampTimes = (2);/* Number of sample times */
  CorrecteurPI_M->Sizes.numBlocks = (10);/* Number of blocks */
  CorrecteurPI_M->Sizes.numBlockIO = (4);/* Number of block outputs */
  CorrecteurPI_M->Sizes.numBlockPrms = (15);/* Sum of parameter "widths" */
  return CorrecteurPI_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/

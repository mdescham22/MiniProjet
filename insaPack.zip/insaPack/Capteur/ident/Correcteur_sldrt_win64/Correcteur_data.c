/*
 * Correcteur_data.c
 *
 * Classroom License -- for classroom instructional use only.  Not for
 * government, commercial, academic research, or other organizational use.
 *
 * Code generation for model "Correcteur".
 *
 * Model version              : 1.85
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Thu May 11 17:06:42 2023
 *
 * Target selection: sldrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Correcteur.h"
#include "Correcteur_private.h"

/* Block parameters (default storage) */
P_Correcteur_T Correcteur_P = {
  /* Expression: 1
   * Referenced by: '<Root>/Step'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<Root>/Step'
   */
  0.0,

  /* Expression: 12
   * Referenced by: '<Root>/Step'
   */
  12.0,

  /* Computed Parameter: TransferFcn_A
   * Referenced by: '<Root>/Transfer Fcn'
   */
  { -0.95884683153132433, -27.384515317083178, -13.018583928890465,
    -184.34400541088158 },

  /* Computed Parameter: TransferFcn_C
   * Referenced by: '<Root>/Transfer Fcn'
   */
  { -2.1850008131796548, 6.0590840439548144, 7.3050418685212986,
    65.442881497974057 },

  /* Expression: 0.7
   * Referenced by: '<Root>/Gain'
   */
  0.7
};

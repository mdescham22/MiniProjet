clear
clc

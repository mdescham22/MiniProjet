clear
clc
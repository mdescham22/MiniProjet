/*
 * SimulinkFINAL.c
 *
 * Classroom License -- for classroom instructional use only.  Not for
 * government, commercial, academic research, or other organizational use.
 *
 * Code generation for model "SimulinkFINAL".
 *
 * Model version              : 1.63
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Tue May 23 14:53:04 2023
 *
 * Target selection: sldrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "SimulinkFINAL.h"
#include "SimulinkFINAL_private.h"
#include "SimulinkFINAL_dt.h"

/* options for Simulink Desktop Real-Time board 0 */
static double SLDRTBoardOptions0[] = {
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
};

/* list of Simulink Desktop Real-Time timers */
const int SLDRTTimerCount = 1;
const double SLDRTTimers[2] = {
  0.01, 0.0,
};

/* list of Simulink Desktop Real-Time boards */
const int SLDRTBoardCount = 1;
SLDRTBOARD SLDRTBoards[1] = {
  { "National_Instruments/PCI-6024E", 4294967295U, 6, SLDRTBoardOptions0 },
};

/* Block signals (default storage) */
B_SimulinkFINAL_T SimulinkFINAL_B;

/* Continuous states */
X_SimulinkFINAL_T SimulinkFINAL_X;

/* Block states (default storage) */
DW_SimulinkFINAL_T SimulinkFINAL_DW;

/* Real-time model */
RT_MODEL_SimulinkFINAL_T SimulinkFINAL_M_;
RT_MODEL_SimulinkFINAL_T *const SimulinkFINAL_M = &SimulinkFINAL_M_;

/*
 * This function updates continuous states using the ODE3 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  /* Solver Matrices */
  static const real_T rt_ODE3_A[3] = {
    1.0/2.0, 3.0/4.0, 1.0
  };

  static const real_T rt_ODE3_B[3][3] = {
    { 1.0/2.0, 0.0, 0.0 },

    { 0.0, 3.0/4.0, 0.0 },

    { 2.0/9.0, 1.0/3.0, 4.0/9.0 }
  };

  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE3_IntgData *id = (ODE3_IntgData *)rtsiGetSolverData(si);
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T hB[3];
  int_T i;
  int_T nXc = 2;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  /* Save the state values at time t in y, we'll use x as ynew. */
  (void) memcpy(y, x,
                (uint_T)nXc*sizeof(real_T));

  /* Assumes that rtsiSetT and ModelOutputs are up-to-date */
  /* f0 = f(t,y) */
  rtsiSetdX(si, f0);
  SimulinkFINAL_derivatives();

  /* f(:,2) = feval(odefile, t + hA(1), y + f*hB(:,1), args(:)(*)); */
  hB[0] = h * rt_ODE3_B[0][0];
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[0]);
  rtsiSetdX(si, f1);
  SimulinkFINAL_output();
  SimulinkFINAL_derivatives();

  /* f(:,3) = feval(odefile, t + hA(2), y + f*hB(:,2), args(:)(*)); */
  for (i = 0; i <= 1; i++) {
    hB[i] = h * rt_ODE3_B[1][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[1]);
  rtsiSetdX(si, f2);
  SimulinkFINAL_output();
  SimulinkFINAL_derivatives();

  /* tnew = t + hA(3);
     ynew = y + f*hB(:,3); */
  for (i = 0; i <= 2; i++) {
    hB[i] = h * rt_ODE3_B[2][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2]);
  }

  rtsiSetT(si, tnew);
  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/* Model output function */
void SimulinkFINAL_output(void)
{
  real_T *lastU;
  real_T rtb_Gain_o;
  real_T rtb_Derivative;
  real_T rtb_Integrator;
  real_T rtb_Gain_f;
  if (rtmIsMajorTimeStep(SimulinkFINAL_M)) {
    /* set solver stop time */
    if (!(SimulinkFINAL_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&SimulinkFINAL_M->solverInfo,
                            ((SimulinkFINAL_M->Timing.clockTickH0 + 1) *
        SimulinkFINAL_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&SimulinkFINAL_M->solverInfo,
                            ((SimulinkFINAL_M->Timing.clockTick0 + 1) *
        SimulinkFINAL_M->Timing.stepSize0 + SimulinkFINAL_M->Timing.clockTickH0 *
        SimulinkFINAL_M->Timing.stepSize0 * 4294967296.0));
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(SimulinkFINAL_M)) {
    SimulinkFINAL_M->Timing.t[0] = rtsiGetT(&SimulinkFINAL_M->solverInfo);
  }

  /* Step: '<Root>/Step1' */
  if (SimulinkFINAL_M->Timing.t[0] < SimulinkFINAL_P.Step1_Time) {
    rtb_Gain_o = SimulinkFINAL_P.Step1_Y0;
  } else {
    rtb_Gain_o = SimulinkFINAL_P.Step1_YFinal;
  }

  /* End of Step: '<Root>/Step1' */

  /* Sum: '<Root>/Sum2' incorporates:
   *  Constant: '<Root>/Constant'
   *  Gain: '<Root>/Gain'
   */
  SimulinkFINAL_B.U = SimulinkFINAL_P.Gain_Gain * rtb_Gain_o +
    SimulinkFINAL_P.Constant_Value;
  if (rtmIsMajorTimeStep(SimulinkFINAL_M)) {
    /* S-Function (sldrtai): '<Root>/Analog Input1' */
    /* S-Function Block: <Root>/Analog Input1 */
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE) SimulinkFINAL_P.AnalogInput1_RangeMode;
      parm.rangeidx = SimulinkFINAL_P.AnalogInput1_VoltRange;
      RTBIO_DriverIO(0, ANALOGINPUT, IOREAD, 1,
                     &SimulinkFINAL_P.AnalogInput1_Channels,
                     &SimulinkFINAL_B.InPos, &parm);
    }

    /* S-Function (sldrtai): '<Root>/Analog Input2' */
    /* S-Function Block: <Root>/Analog Input2 */
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE) SimulinkFINAL_P.AnalogInput2_RangeMode;
      parm.rangeidx = SimulinkFINAL_P.AnalogInput2_VoltRange;
      RTBIO_DriverIO(0, ANALOGINPUT, IOREAD, 1,
                     &SimulinkFINAL_P.AnalogInput2_Channels,
                     &SimulinkFINAL_B.InMot, &parm);
    }
  }

  /* Gain: '<S1>/Gain' incorporates:
   *  Sum: '<Root>/Sum1'
   */
  rtb_Gain_o = (SimulinkFINAL_B.U - SimulinkFINAL_B.InPos) *
    SimulinkFINAL_P.Gain_Gain_j;

  /* Gain: '<S1>/Gain1' */
  SimulinkFINAL_B.Gain1 = SimulinkFINAL_P.Gain1_Gain * rtb_Gain_o;

  /* Derivative: '<S1>/Derivative' incorporates:
   *  Derivative: '<S2>/Derivative'
   */
  rtb_Derivative = SimulinkFINAL_M->Timing.t[0];
  if ((SimulinkFINAL_DW.TimeStampA >= rtb_Derivative) &&
      (SimulinkFINAL_DW.TimeStampB >= rtb_Derivative)) {
    rtb_Integrator = 0.0;
  } else {
    rtb_Integrator = SimulinkFINAL_DW.TimeStampA;
    lastU = &SimulinkFINAL_DW.LastUAtTimeA;
    if (SimulinkFINAL_DW.TimeStampA < SimulinkFINAL_DW.TimeStampB) {
      if (SimulinkFINAL_DW.TimeStampB < rtb_Derivative) {
        rtb_Integrator = SimulinkFINAL_DW.TimeStampB;
        lastU = &SimulinkFINAL_DW.LastUAtTimeB;
      }
    } else {
      if (SimulinkFINAL_DW.TimeStampA >= rtb_Derivative) {
        rtb_Integrator = SimulinkFINAL_DW.TimeStampB;
        lastU = &SimulinkFINAL_DW.LastUAtTimeB;
      }
    }

    rtb_Integrator = (SimulinkFINAL_B.Gain1 - *lastU) / (rtb_Derivative -
      rtb_Integrator);
  }

  /* End of Derivative: '<S1>/Derivative' */

  /* Gain: '<Root>/Gain1' incorporates:
   *  Gain: '<S1>/Gain2'
   *  Integrator: '<S1>/Integrator'
   *  Sum: '<S1>/Sum1'
   */
  SimulinkFINAL_B.out = ((SimulinkFINAL_P.Gain2_Gain * rtb_Gain_o +
    SimulinkFINAL_X.Integrator_CSTATE) + rtb_Integrator) *
    SimulinkFINAL_P.Gain1_Gain_p;
  if (rtmIsMajorTimeStep(SimulinkFINAL_M)) {
    /* Gain: '<S2>/Gain' incorporates:
     *  Sum: '<Root>/Sum3'
     */
    rtb_Gain_f = (SimulinkFINAL_B.InPos - SimulinkFINAL_B.InMot) *
      SimulinkFINAL_P.Gain_Gain_a;

    /* Gain: '<S2>/Gain2' */
    SimulinkFINAL_B.Gain2 = SimulinkFINAL_P.Gain2_Gain_b * rtb_Gain_f;

    /* Gain: '<S2>/Gain1' */
    SimulinkFINAL_B.Gain1_b = SimulinkFINAL_P.Gain1_Gain_e * rtb_Gain_f;
  }

  /* Derivative: '<S2>/Derivative' */
  if ((SimulinkFINAL_DW.TimeStampA_l >= rtb_Derivative) &&
      (SimulinkFINAL_DW.TimeStampB_m >= rtb_Derivative)) {
    rtb_Derivative = 0.0;
  } else {
    rtb_Integrator = SimulinkFINAL_DW.TimeStampA_l;
    lastU = &SimulinkFINAL_DW.LastUAtTimeA_f;
    if (SimulinkFINAL_DW.TimeStampA_l < SimulinkFINAL_DW.TimeStampB_m) {
      if (SimulinkFINAL_DW.TimeStampB_m < rtb_Derivative) {
        rtb_Integrator = SimulinkFINAL_DW.TimeStampB_m;
        lastU = &SimulinkFINAL_DW.LastUAtTimeB_b;
      }
    } else {
      if (SimulinkFINAL_DW.TimeStampA_l >= rtb_Derivative) {
        rtb_Integrator = SimulinkFINAL_DW.TimeStampB_m;
        lastU = &SimulinkFINAL_DW.LastUAtTimeB_b;
      }
    }

    rtb_Derivative = (SimulinkFINAL_B.Gain1_b - *lastU) / (rtb_Derivative -
      rtb_Integrator);
  }

  /* Sum: '<S2>/Sum1' incorporates:
   *  Integrator: '<S2>/Integrator'
   */
  SimulinkFINAL_B.Sum1 = (SimulinkFINAL_B.Gain2 +
    SimulinkFINAL_X.Integrator_CSTATE_n) + rtb_Derivative;
  if (rtmIsMajorTimeStep(SimulinkFINAL_M)) {
    /* S-Function (sldrtao): '<Root>/Analog Output1' */
    /* S-Function Block: <Root>/Analog Output1 */
    {
      {
        ANALOGIOPARM parm;
        parm.mode = (RANGEMODE) SimulinkFINAL_P.AnalogOutput1_RangeMode;
        parm.rangeidx = SimulinkFINAL_P.AnalogOutput1_VoltRange;
        RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                       &SimulinkFINAL_P.AnalogOutput1_Channels, ((real_T*)
          (&SimulinkFINAL_B.out)), &parm);
      }
    }

    /* S-Function (sldrtao): '<Root>/Analog Output2' */
    /* S-Function Block: <Root>/Analog Output2 */
    {
      {
        ANALOGIOPARM parm;
        parm.mode = (RANGEMODE) SimulinkFINAL_P.AnalogOutput2_RangeMode;
        parm.rangeidx = SimulinkFINAL_P.AnalogOutput2_VoltRange;
        RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                       &SimulinkFINAL_P.AnalogOutput2_Channels, ((real_T*)
          (&SimulinkFINAL_B.Sum1)), &parm);
      }
    }

    /* ToAsyncQueueBlock generated from: '<Root>/Analog Input1' */
    if (rtmIsMajorTimeStep(SimulinkFINAL_M)) {
      {
        double time = SimulinkFINAL_M->Timing.t[1];
        void *pData = (void *)&SimulinkFINAL_B.InPos;
        int32_T size = 1*sizeof(real_T);
        sendToAsyncQueueTgtAppSvc(2514161704U, time, pData, size);
      }
    }

    /* ToAsyncQueueBlock generated from: '<Root>/Analog Input2' */
    if (rtmIsMajorTimeStep(SimulinkFINAL_M)) {
      {
        double time = SimulinkFINAL_M->Timing.t[1];
        void *pData = (void *)&SimulinkFINAL_B.InMot;
        int32_T size = 1*sizeof(real_T);
        sendToAsyncQueueTgtAppSvc(855693766U, time, pData, size);
      }
    }

    /* ToAsyncQueueBlock generated from: '<Root>/Gain1' */
    if (rtmIsMajorTimeStep(SimulinkFINAL_M)) {
      {
        double time = SimulinkFINAL_M->Timing.t[1];
        void *pData = (void *)&SimulinkFINAL_B.out;
        int32_T size = 1*sizeof(real_T);
        sendToAsyncQueueTgtAppSvc(624553570U, time, pData, size);
      }
    }

    /* ToAsyncQueueBlock generated from: '<Root>/Subsystem2' */
    if (rtmIsMajorTimeStep(SimulinkFINAL_M)) {
      {
        double time = SimulinkFINAL_M->Timing.t[1];
        void *pData = (void *)&SimulinkFINAL_B.Sum1;
        int32_T size = 1*sizeof(real_T);
        sendToAsyncQueueTgtAppSvc(393808582U, time, pData, size);
      }
    }

    /* ToAsyncQueueBlock generated from: '<Root>/Sum2' */
    if (rtmIsMajorTimeStep(SimulinkFINAL_M)) {
      {
        double time = SimulinkFINAL_M->Timing.t[1];
        void *pData = (void *)&SimulinkFINAL_B.U;
        int32_T size = 1*sizeof(real_T);
        sendToAsyncQueueTgtAppSvc(1873110582U, time, pData, size);
      }
    }

    /* Gain: '<S2>/Gain3' */
    SimulinkFINAL_B.Gain3_d = SimulinkFINAL_P.Gain3_Gain_e * rtb_Gain_f;
  }

  /* Gain: '<S1>/Gain3' */
  SimulinkFINAL_B.Gain3 = SimulinkFINAL_P.Gain3_Gain * rtb_Gain_o;
}

/* Model update function */
void SimulinkFINAL_update(void)
{
  real_T *lastU;

  /* Update for Derivative: '<S1>/Derivative' */
  if (SimulinkFINAL_DW.TimeStampA == (rtInf)) {
    SimulinkFINAL_DW.TimeStampA = SimulinkFINAL_M->Timing.t[0];
    lastU = &SimulinkFINAL_DW.LastUAtTimeA;
  } else if (SimulinkFINAL_DW.TimeStampB == (rtInf)) {
    SimulinkFINAL_DW.TimeStampB = SimulinkFINAL_M->Timing.t[0];
    lastU = &SimulinkFINAL_DW.LastUAtTimeB;
  } else if (SimulinkFINAL_DW.TimeStampA < SimulinkFINAL_DW.TimeStampB) {
    SimulinkFINAL_DW.TimeStampA = SimulinkFINAL_M->Timing.t[0];
    lastU = &SimulinkFINAL_DW.LastUAtTimeA;
  } else {
    SimulinkFINAL_DW.TimeStampB = SimulinkFINAL_M->Timing.t[0];
    lastU = &SimulinkFINAL_DW.LastUAtTimeB;
  }

  *lastU = SimulinkFINAL_B.Gain1;

  /* End of Update for Derivative: '<S1>/Derivative' */

  /* Update for Derivative: '<S2>/Derivative' */
  if (SimulinkFINAL_DW.TimeStampA_l == (rtInf)) {
    SimulinkFINAL_DW.TimeStampA_l = SimulinkFINAL_M->Timing.t[0];
    lastU = &SimulinkFINAL_DW.LastUAtTimeA_f;
  } else if (SimulinkFINAL_DW.TimeStampB_m == (rtInf)) {
    SimulinkFINAL_DW.TimeStampB_m = SimulinkFINAL_M->Timing.t[0];
    lastU = &SimulinkFINAL_DW.LastUAtTimeB_b;
  } else if (SimulinkFINAL_DW.TimeStampA_l < SimulinkFINAL_DW.TimeStampB_m) {
    SimulinkFINAL_DW.TimeStampA_l = SimulinkFINAL_M->Timing.t[0];
    lastU = &SimulinkFINAL_DW.LastUAtTimeA_f;
  } else {
    SimulinkFINAL_DW.TimeStampB_m = SimulinkFINAL_M->Timing.t[0];
    lastU = &SimulinkFINAL_DW.LastUAtTimeB_b;
  }

  *lastU = SimulinkFINAL_B.Gain1_b;

  /* End of Update for Derivative: '<S2>/Derivative' */
  if (rtmIsMajorTimeStep(SimulinkFINAL_M)) {
    rt_ertODEUpdateContinuousStates(&SimulinkFINAL_M->solverInfo);
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++SimulinkFINAL_M->Timing.clockTick0)) {
    ++SimulinkFINAL_M->Timing.clockTickH0;
  }

  SimulinkFINAL_M->Timing.t[0] = rtsiGetSolverStopTime
    (&SimulinkFINAL_M->solverInfo);

  {
    /* Update absolute timer for sample time: [0.01s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick1"
     * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++SimulinkFINAL_M->Timing.clockTick1)) {
      ++SimulinkFINAL_M->Timing.clockTickH1;
    }

    SimulinkFINAL_M->Timing.t[1] = SimulinkFINAL_M->Timing.clockTick1 *
      SimulinkFINAL_M->Timing.stepSize1 + SimulinkFINAL_M->Timing.clockTickH1 *
      SimulinkFINAL_M->Timing.stepSize1 * 4294967296.0;
  }
}

/* Derivatives for root system: '<Root>' */
void SimulinkFINAL_derivatives(void)
{
  XDot_SimulinkFINAL_T *_rtXdot;
  _rtXdot = ((XDot_SimulinkFINAL_T *) SimulinkFINAL_M->derivs);

  /* Derivatives for Integrator: '<S1>/Integrator' */
  _rtXdot->Integrator_CSTATE = SimulinkFINAL_B.Gain3;

  /* Derivatives for Integrator: '<S2>/Integrator' */
  _rtXdot->Integrator_CSTATE_n = SimulinkFINAL_B.Gain3_d;
}

/* Model initialize function */
void SimulinkFINAL_initialize(void)
{
  /* Start for S-Function (sldrtao): '<Root>/Analog Output1' */

  /* S-Function Block: <Root>/Analog Output1 */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE) SimulinkFINAL_P.AnalogOutput1_RangeMode;
      parm.rangeidx = SimulinkFINAL_P.AnalogOutput1_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                     &SimulinkFINAL_P.AnalogOutput1_Channels,
                     &SimulinkFINAL_P.AnalogOutput1_InitialValue, &parm);
    }
  }

  /* Start for S-Function (sldrtao): '<Root>/Analog Output2' */

  /* S-Function Block: <Root>/Analog Output2 */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE) SimulinkFINAL_P.AnalogOutput2_RangeMode;
      parm.rangeidx = SimulinkFINAL_P.AnalogOutput2_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                     &SimulinkFINAL_P.AnalogOutput2_Channels,
                     &SimulinkFINAL_P.AnalogOutput2_InitialValue, &parm);
    }
  }

  /* InitializeConditions for Integrator: '<S1>/Integrator' */
  SimulinkFINAL_X.Integrator_CSTATE = SimulinkFINAL_P.Integrator_IC;

  /* InitializeConditions for Derivative: '<S1>/Derivative' */
  SimulinkFINAL_DW.TimeStampA = (rtInf);
  SimulinkFINAL_DW.TimeStampB = (rtInf);

  /* InitializeConditions for Integrator: '<S2>/Integrator' */
  SimulinkFINAL_X.Integrator_CSTATE_n = SimulinkFINAL_P.Integrator_IC_p;

  /* InitializeConditions for Derivative: '<S2>/Derivative' */
  SimulinkFINAL_DW.TimeStampA_l = (rtInf);
  SimulinkFINAL_DW.TimeStampB_m = (rtInf);
}

/* Model terminate function */
void SimulinkFINAL_terminate(void)
{
  /* Terminate for S-Function (sldrtao): '<Root>/Analog Output1' */

  /* S-Function Block: <Root>/Analog Output1 */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE) SimulinkFINAL_P.AnalogOutput1_RangeMode;
      parm.rangeidx = SimulinkFINAL_P.AnalogOutput1_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                     &SimulinkFINAL_P.AnalogOutput1_Channels,
                     &SimulinkFINAL_P.AnalogOutput1_FinalValue, &parm);
    }
  }

  /* Terminate for S-Function (sldrtao): '<Root>/Analog Output2' */

  /* S-Function Block: <Root>/Analog Output2 */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE) SimulinkFINAL_P.AnalogOutput2_RangeMode;
      parm.rangeidx = SimulinkFINAL_P.AnalogOutput2_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                     &SimulinkFINAL_P.AnalogOutput2_Channels,
                     &SimulinkFINAL_P.AnalogOutput2_FinalValue, &parm);
    }
  }
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/

/* Solver interface called by GRT_Main */
#ifndef USE_GENERATED_SOLVER

void rt_ODECreateIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEDestroyIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEUpdateContinuousStates(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

#endif

void MdlOutputs(int_T tid)
{
  SimulinkFINAL_output();
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  SimulinkFINAL_update();
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  SimulinkFINAL_initialize();
}

void MdlTerminate(void)
{
  SimulinkFINAL_terminate();
}

/* Registration function */
RT_MODEL_SimulinkFINAL_T *SimulinkFINAL(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)SimulinkFINAL_M, 0,
                sizeof(RT_MODEL_SimulinkFINAL_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&SimulinkFINAL_M->solverInfo,
                          &SimulinkFINAL_M->Timing.simTimeStep);
    rtsiSetTPtr(&SimulinkFINAL_M->solverInfo, &rtmGetTPtr(SimulinkFINAL_M));
    rtsiSetStepSizePtr(&SimulinkFINAL_M->solverInfo,
                       &SimulinkFINAL_M->Timing.stepSize0);
    rtsiSetdXPtr(&SimulinkFINAL_M->solverInfo, &SimulinkFINAL_M->derivs);
    rtsiSetContStatesPtr(&SimulinkFINAL_M->solverInfo, (real_T **)
                         &SimulinkFINAL_M->contStates);
    rtsiSetNumContStatesPtr(&SimulinkFINAL_M->solverInfo,
      &SimulinkFINAL_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&SimulinkFINAL_M->solverInfo,
      &SimulinkFINAL_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&SimulinkFINAL_M->solverInfo,
      &SimulinkFINAL_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&SimulinkFINAL_M->solverInfo,
      &SimulinkFINAL_M->periodicContStateRanges);
    rtsiSetErrorStatusPtr(&SimulinkFINAL_M->solverInfo, (&rtmGetErrorStatus
      (SimulinkFINAL_M)));
    rtsiSetRTModelPtr(&SimulinkFINAL_M->solverInfo, SimulinkFINAL_M);
  }

  rtsiSetSimTimeStep(&SimulinkFINAL_M->solverInfo, MAJOR_TIME_STEP);
  SimulinkFINAL_M->intgData.y = SimulinkFINAL_M->odeY;
  SimulinkFINAL_M->intgData.f[0] = SimulinkFINAL_M->odeF[0];
  SimulinkFINAL_M->intgData.f[1] = SimulinkFINAL_M->odeF[1];
  SimulinkFINAL_M->intgData.f[2] = SimulinkFINAL_M->odeF[2];
  SimulinkFINAL_M->contStates = ((real_T *) &SimulinkFINAL_X);
  rtsiSetSolverData(&SimulinkFINAL_M->solverInfo, (void *)
                    &SimulinkFINAL_M->intgData);
  rtsiSetSolverName(&SimulinkFINAL_M->solverInfo,"ode3");

  /* Initialize timing info */
  {
    int_T *mdlTsMap = SimulinkFINAL_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    mdlTsMap[1] = 1;
    SimulinkFINAL_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    SimulinkFINAL_M->Timing.sampleTimes =
      (&SimulinkFINAL_M->Timing.sampleTimesArray[0]);
    SimulinkFINAL_M->Timing.offsetTimes =
      (&SimulinkFINAL_M->Timing.offsetTimesArray[0]);

    /* task periods */
    SimulinkFINAL_M->Timing.sampleTimes[0] = (0.0);
    SimulinkFINAL_M->Timing.sampleTimes[1] = (0.01);

    /* task offsets */
    SimulinkFINAL_M->Timing.offsetTimes[0] = (0.0);
    SimulinkFINAL_M->Timing.offsetTimes[1] = (0.0);
  }

  rtmSetTPtr(SimulinkFINAL_M, &SimulinkFINAL_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = SimulinkFINAL_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    mdlSampleHits[1] = 1;
    SimulinkFINAL_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(SimulinkFINAL_M, -1);
  SimulinkFINAL_M->Timing.stepSize0 = 0.01;
  SimulinkFINAL_M->Timing.stepSize1 = 0.01;

  /* External mode info */
  SimulinkFINAL_M->Sizes.checksums[0] = (2954366483U);
  SimulinkFINAL_M->Sizes.checksums[1] = (242659479U);
  SimulinkFINAL_M->Sizes.checksums[2] = (3953700277U);
  SimulinkFINAL_M->Sizes.checksums[3] = (1468142785U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[1];
    SimulinkFINAL_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(SimulinkFINAL_M->extModeInfo,
      &SimulinkFINAL_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(SimulinkFINAL_M->extModeInfo,
                        SimulinkFINAL_M->Sizes.checksums);
    rteiSetTPtr(SimulinkFINAL_M->extModeInfo, rtmGetTPtr(SimulinkFINAL_M));
  }

  SimulinkFINAL_M->solverInfoPtr = (&SimulinkFINAL_M->solverInfo);
  SimulinkFINAL_M->Timing.stepSize = (0.01);
  rtsiSetFixedStepSize(&SimulinkFINAL_M->solverInfo, 0.01);
  rtsiSetSolverMode(&SimulinkFINAL_M->solverInfo, SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  SimulinkFINAL_M->blockIO = ((void *) &SimulinkFINAL_B);
  (void) memset(((void *) &SimulinkFINAL_B), 0,
                sizeof(B_SimulinkFINAL_T));

  /* parameters */
  SimulinkFINAL_M->defaultParam = ((real_T *)&SimulinkFINAL_P);

  /* states (continuous) */
  {
    real_T *x = (real_T *) &SimulinkFINAL_X;
    SimulinkFINAL_M->contStates = (x);
    (void) memset((void *)&SimulinkFINAL_X, 0,
                  sizeof(X_SimulinkFINAL_T));
  }

  /* states (dwork) */
  SimulinkFINAL_M->dwork = ((void *) &SimulinkFINAL_DW);
  (void) memset((void *)&SimulinkFINAL_DW, 0,
                sizeof(DW_SimulinkFINAL_T));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    SimulinkFINAL_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 14;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.PTransTable = &rtPTransTable;
  }

  /* Initialize Sizes */
  SimulinkFINAL_M->Sizes.numContStates = (2);/* Number of continuous states */
  SimulinkFINAL_M->Sizes.numPeriodicContStates = (0);
                                      /* Number of periodic continuous states */
  SimulinkFINAL_M->Sizes.numY = (0);   /* Number of model outputs */
  SimulinkFINAL_M->Sizes.numU = (0);   /* Number of model inputs */
  SimulinkFINAL_M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  SimulinkFINAL_M->Sizes.numSampTimes = (2);/* Number of sample times */
  SimulinkFINAL_M->Sizes.numBlocks = (30);/* Number of blocks */
  SimulinkFINAL_M->Sizes.numBlockIO = (10);/* Number of block outputs */
  SimulinkFINAL_M->Sizes.numBlockPrms = (40);/* Sum of parameter "widths" */
  return SimulinkFINAL_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/

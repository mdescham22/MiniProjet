/*
 * lab2.c
 *
 * Classroom License -- for classroom instructional use only.  Not for
 * government, commercial, academic research, or other organizational use.
 *
 * Code generation for model "lab2".
 *
 * Model version              : 1.36
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Thu Apr 20 14:39:57 2023
 *
 * Target selection: sldrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "lab2.h"
#include "lab2_private.h"
#include "lab2_dt.h"

/* options for Simulink Desktop Real-Time board 0 */
static double SLDRTBoardOptions0[] = {
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
};

/* list of Simulink Desktop Real-Time timers */
const int SLDRTTimerCount = 1;
const double SLDRTTimers[2] = {
  0.0185, 0.0,
};

/* list of Simulink Desktop Real-Time boards */
const int SLDRTBoardCount = 1;
SLDRTBOARD SLDRTBoards[1] = {
  { "National_Instruments/PCI-6024E", 4294967295U, 6, SLDRTBoardOptions0 },
};

/* Block signals (default storage) */
B_lab2_T lab2_B;

/* Block states (default storage) */
DW_lab2_T lab2_DW;

/* Real-time model */
RT_MODEL_lab2_T lab2_M_;
RT_MODEL_lab2_T *const lab2_M = &lab2_M_;

/* Model output function */
void lab2_output(void)
{
  /* S-Function (sldrtai): '<Root>/Analog Input' */
  /* S-Function Block: <Root>/Analog Input */
  {
    ANALOGIOPARM parm;
    parm.mode = (RANGEMODE) lab2_P.AnalogInput_RangeMode;
    parm.rangeidx = lab2_P.AnalogInput_VoltRange;
    RTBIO_DriverIO(0, ANALOGINPUT, IOREAD, 1, &lab2_P.AnalogInput_Channels,
                   &lab2_B.AnalogInput, &parm);
  }

  /* ToAsyncQueueBlock generated from: '<Root>/Analog Input' */
  {
    {
      double time = lab2_M->Timing.t[0];
      void *pData = (void *)&lab2_B.AnalogInput;
      int32_T size = 1*sizeof(real_T);
      sendToAsyncQueueTgtAppSvc(498692524U, time, pData, size);
    }
  }

  /* FromWorkspace: '<Root>/From Workspace' */
  {
    real_T *pDataValues = (real_T *) lab2_DW.FromWorkspace_PWORK.DataPtr;
    real_T *pTimeValues = (real_T *) lab2_DW.FromWorkspace_PWORK.TimePtr;
    int_T currTimeIndex = lab2_DW.FromWorkspace_IWORK.PrevIndex;
    real_T t = lab2_M->Timing.t[0];

    /* Get index */
    if (t <= pTimeValues[0]) {
      currTimeIndex = 0;
    } else if (t >= pTimeValues[496]) {
      currTimeIndex = 495;
    } else {
      if (t < pTimeValues[currTimeIndex]) {
        while (t < pTimeValues[currTimeIndex]) {
          currTimeIndex--;
        }
      } else {
        while (t >= pTimeValues[currTimeIndex + 1]) {
          currTimeIndex++;
        }
      }
    }

    lab2_DW.FromWorkspace_IWORK.PrevIndex = currTimeIndex;

    /* Post output */
    {
      real_T t1 = pTimeValues[currTimeIndex];
      real_T t2 = pTimeValues[currTimeIndex + 1];
      if (t1 == t2) {
        if (t < t1) {
          lab2_B.FromWorkspace = pDataValues[currTimeIndex];
        } else {
          lab2_B.FromWorkspace = pDataValues[currTimeIndex + 1];
        }
      } else {
        real_T f1 = (t2 - t) / (t2 - t1);
        real_T f2 = 1.0 - f1;
        real_T d1;
        real_T d2;
        int_T TimeIndex= currTimeIndex;
        d1 = pDataValues[TimeIndex];
        d2 = pDataValues[TimeIndex + 1];
        lab2_B.FromWorkspace = (real_T) rtInterpolate(d1, d2, f1, f2);
        pDataValues += 497;
      }
    }
  }

  /* S-Function (sldrtao): '<Root>/Analog Output' */
  /* S-Function Block: <Root>/Analog Output */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE) lab2_P.AnalogOutput_RangeMode;
      parm.rangeidx = lab2_P.AnalogOutput_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1, &lab2_P.AnalogOutput_Channels,
                     ((real_T*) (&lab2_B.FromWorkspace)), &parm);
    }
  }

  /* ToAsyncQueueBlock generated from: '<Root>/From Workspace' */
  {
    {
      double time = lab2_M->Timing.t[0];
      void *pData = (void *)&lab2_B.FromWorkspace;
      int32_T size = 1*sizeof(real_T);
      sendToAsyncQueueTgtAppSvc(892365529U, time, pData, size);
    }
  }
}

/* Model update function */
void lab2_update(void)
{
  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++lab2_M->Timing.clockTick0)) {
    ++lab2_M->Timing.clockTickH0;
  }

  lab2_M->Timing.t[0] = lab2_M->Timing.clockTick0 * lab2_M->Timing.stepSize0 +
    lab2_M->Timing.clockTickH0 * lab2_M->Timing.stepSize0 * 4294967296.0;
}

/* Model initialize function */
void lab2_initialize(void)
{
  /* Start for FromWorkspace: '<Root>/From Workspace' */
  {
    static real_T pTimeValues0[] = { 0.0, 0.0185, 0.037, 0.055499999999999994,
      0.074, 0.0925, 0.11099999999999999, 0.1295, 0.148, 0.16649999999999998,
      0.185, 0.2035, 0.22199999999999998, 0.2405, 0.259, 0.27749999999999997,
      0.296, 0.3145, 0.33299999999999996, 0.3515, 0.37, 0.38849999999999996,
      0.407, 0.4255, 0.44399999999999995, 0.46249999999999997, 0.481, 0.4995,
      0.518, 0.5365, 0.55499999999999994, 0.5735, 0.592, 0.61049999999999993,
      0.629, 0.6475, 0.66599999999999993, 0.6845, 0.703, 0.72149999999999992,
      0.74, 0.7585, 0.77699999999999991, 0.7955, 0.814, 0.83249999999999991,
      0.851, 0.86949999999999994, 0.8879999999999999, 0.9065,
      0.92499999999999993, 0.9435, 0.962, 0.98049999999999993, 0.999,
      1.0174999999999998, 1.036, 1.0545, 1.073, 1.0915, 1.1099999999999999,
      1.1284999999999998, 1.147, 1.1655, 1.184, 1.2025, 1.2209999999999999,
      1.2395, 1.258, 1.2765, 1.295, 1.3135, 1.3319999999999999, 1.3505, 1.369,
      1.3875, 1.406, 1.4244999999999999, 1.4429999999999998, 1.4615, 1.48,
      1.4985, 1.517, 1.5354999999999999, 1.5539999999999998, 1.5725, 1.591,
      1.6095, 1.628, 1.6464999999999999, 1.6649999999999998, 1.6835, 1.702,
      1.7205, 1.7389999999999999, 1.7574999999999998, 1.7759999999999998, 1.7945,
      1.813, 1.8315, 1.8499999999999999, 1.8684999999999998, 1.887, 1.9055,
      1.924, 1.9425, 1.9609999999999999, 1.9794999999999998, 1.998,
      2.0164999999999997, 2.0349999999999997, 2.0535, 2.072, 2.0905, 2.109,
      2.1275, 2.146, 2.1645, 2.183, 2.2015, 2.2199999999999998,
      2.2384999999999997, 2.2569999999999997, 2.2755, 2.294, 2.3125, 2.331,
      2.3495, 2.368, 2.3865, 2.405, 2.4234999999999998, 2.4419999999999997,
      2.4604999999999997, 2.479, 2.4975, 2.516, 2.5345, 2.553, 2.5715, 2.59,
      2.6085, 2.627, 2.6454999999999997, 2.6639999999999997, 2.6824999999999997,
      2.701, 2.7195, 2.738, 2.7565, 2.775, 2.7935, 2.812, 2.8305,
      2.8489999999999998, 2.8674999999999997, 2.8859999999999997,
      2.9044999999999996, 2.923, 2.9415, 2.96, 2.9785, 2.997, 3.0155, 3.034,
      3.0524999999999998, 3.0709999999999997, 3.0894999999999997,
      3.1079999999999997, 3.1265, 3.145, 3.1635, 3.182, 3.2005, 3.219, 3.2375,
      3.256, 3.2744999999999997, 3.2929999999999997, 3.3114999999999997,
      3.3299999999999996, 3.3485, 3.367, 3.3855, 3.404, 3.4225, 3.441, 3.4595,
      3.4779999999999998, 3.4964999999999997, 3.5149999999999997,
      3.5334999999999996, 3.5519999999999996, 3.5705, 3.589, 3.6075, 3.626,
      3.6445, 3.663, 3.6814999999999998, 3.6999999999999997, 3.7184999999999997,
      3.7369999999999997, 3.7554999999999996, 3.774, 3.7925, 3.811, 3.8295,
      3.848, 3.8665, 3.885, 3.9034999999999997, 3.9219999999999997,
      3.9404999999999997, 3.9589999999999996, 3.9774999999999996, 3.996, 4.0145,
      4.0329999999999995, 4.0515, 4.0699999999999994, 4.0885, 4.107, 4.1255,
      4.144, 4.1625, 4.181, 4.1995, 4.218, 4.2364999999999995, 4.255,
      4.2734999999999994, 4.292, 4.3105, 4.329, 4.3475, 4.366, 4.3845, 4.403,
      4.4215, 4.4399999999999995, 4.4585, 4.4769999999999994, 4.4955,
      4.5139999999999993, 4.5325, 4.551, 4.5695, 4.588, 4.6065000000000005,
      4.625, 4.6435, 4.6620000000000008, 4.6805, 4.6990000000000007, 4.7175,
      4.7360000000000007, 4.7545, 4.7730000000000006, 4.7915, 4.8100000000000005,
      4.8285, 4.847, 4.8655, 4.884, 4.9025000000000007, 4.921,
      4.9395000000000007, 4.958, 4.9765000000000006, 4.995, 5.0135000000000005,
      5.032, 5.0505, 5.069, 5.0875, 5.1060000000000008, 5.1245,
      5.1430000000000007, 5.1615, 5.18, 5.198500000000001, 5.2170000000000005,
      5.2355, 5.2540000000000004, 5.2725000000000009, 5.291, 5.3095, 5.328,
      5.3465000000000007, 5.365, 5.3835, 5.402, 5.4205000000000005, 5.439,
      5.4575000000000005, 5.4760000000000009, 5.4945, 5.513, 5.5315,
      5.5500000000000007, 5.5685, 5.587, 5.6055, 5.6240000000000006, 5.6425,
      5.6610000000000005, 5.6795000000000009, 5.698, 5.7165, 5.735,
      5.7535000000000007, 5.772, 5.7905, 5.809, 5.8275000000000006, 5.846,
      5.8645000000000005, 5.8830000000000009, 5.9015, 5.92, 5.9385,
      5.9570000000000007, 5.9755, 5.994, 6.0125, 6.0310000000000006, 6.0495,
      6.0680000000000005, 6.0865000000000009, 6.105, 6.1235, 6.142,
      6.1605000000000008, 6.179, 6.1975, 6.216, 6.2345000000000006, 6.253,
      6.2715000000000005, 6.2900000000000009, 6.3085, 6.327, 6.3455,
      6.3640000000000008, 6.3825, 6.401, 6.4195, 6.4380000000000006, 6.4565,
      6.475, 6.4935000000000009, 6.5120000000000005, 6.5305, 6.549,
      6.5675000000000008, 6.586, 6.6045, 6.623, 6.6415000000000006, 6.66, 6.6785,
      6.697, 6.7155000000000005, 6.734, 6.7525, 6.7710000000000008, 6.7895,
      6.808, 6.8265, 6.8450000000000006, 6.8635, 6.882, 6.9005,
      6.9190000000000005, 6.9375, 6.956, 6.9745000000000008, 6.993, 7.0115, 7.03,
      7.0485000000000007, 7.067, 7.0855, 7.104, 7.1225000000000005, 7.141,
      7.1595, 7.178, 7.1965, 7.215, 7.2335, 7.2520000000000007, 7.2705, 7.289,
      7.3075, 7.3260000000000005, 7.3445, 7.363, 7.3815, 7.4, 7.4185, 7.437,
      7.4555000000000007, 7.474, 7.4925, 7.511, 7.5295000000000005, 7.548,
      7.5665000000000004, 7.585, 7.6035, 7.622, 7.6405, 7.6590000000000007,
      7.6775, 7.696, 7.7145, 7.7330000000000005, 7.7515, 7.7700000000000005,
      7.7885, 7.807, 7.8255, 7.844, 7.8625000000000007, 7.881, 7.8995, 7.918,
      7.9365000000000006, 7.955, 7.9735000000000005, 7.992, 8.0105, 8.029,
      8.0475, 8.066, 8.0845, 8.103, 8.1215000000000011, 8.14, 8.1585, 8.177,
      8.1955000000000009, 8.214, 8.2325, 8.251, 8.2695, 8.288, 8.3065, 8.325,
      8.3435, 8.362, 8.3805, 8.3990000000000009, 8.4175, 8.436, 8.4545, 8.473,
      8.4915, 8.51, 8.5285000000000011, 8.547, 8.5655, 8.584, 8.6025000000000009,
      8.621, 8.6395, 8.658, 8.6765, 8.695, 8.7135, 8.732, 8.7505, 8.769, 8.7875,
      8.8060000000000009, 8.8245, 8.843, 8.8615, 8.88, 8.8985, 8.917, 8.9355,
      8.954, 8.9725, 8.991, 9.009500000000001, 9.028, 9.0465, 9.065, 9.0835,
      9.102, 9.1205, 9.139, 9.1575, 9.176 } ;

    static real_T pDataValues0[] = { 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 4.2,
      4.2, 4.2, 4.2, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 4.2, 4.2, 4.2, 4.2,
      3.6, 3.6, 3.6, 3.6, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 3.6, 3.6, 3.6,
      3.6, 3.6, 3.6, 3.6, 3.6, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2,
      4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 3.6, 3.6, 3.6, 3.6, 3.6,
      3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2,
      3.6, 3.6, 3.6, 3.6, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2,
      4.2, 3.6, 3.6, 3.6, 3.6, 4.2, 4.2, 4.2, 4.2, 3.6, 3.6, 3.6, 3.6, 4.2, 4.2,
      4.2, 4.2, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6,
      3.6, 3.6, 3.6, 4.2, 4.2, 4.2, 4.2, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6,
      4.2, 4.2, 4.2, 4.2, 3.6, 3.6, 3.6, 3.6, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2,
      4.2, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2,
      4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 3.6,
      3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 4.2, 4.2, 4.2, 4.2,
      4.2, 4.2, 4.2, 4.2, 3.6, 3.6, 3.6, 3.6, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2,
      4.2, 4.2, 4.2, 4.2, 4.2, 3.6, 3.6, 3.6, 3.6, 4.2, 4.2, 4.2, 4.2, 3.6, 3.6,
      3.6, 3.6, 4.2, 4.2, 4.2, 4.2, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6,
      3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 4.2, 4.2, 4.2, 4.2, 3.6, 3.6, 3.6, 3.6,
      3.6, 3.6, 3.6, 3.6, 4.2, 4.2, 4.2, 4.2, 3.6, 3.6, 3.6, 3.6, 4.2, 4.2, 4.2,
      4.2, 4.2, 4.2, 4.2, 4.2, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 4.2, 4.2,
      4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2,
      4.2, 4.2, 4.2, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6,
      4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 3.6, 3.6, 3.6, 3.6, 4.2, 4.2, 4.2,
      4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 3.6, 3.6, 3.6, 3.6, 4.2, 4.2,
      4.2, 4.2, 3.6, 3.6, 3.6, 3.6, 4.2, 4.2, 4.2, 4.2, 3.6, 3.6, 3.6, 3.6, 3.6,
      3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 4.2, 4.2, 4.2, 4.2,
      3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 4.2, 4.2, 4.2, 4.2, 3.6, 3.6, 3.6,
      3.6, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6,
      3.6, 3.6, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2,
      4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6,
      3.6, 3.6, 3.6, 3.6, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 3.6, 3.6, 3.6,
      3.6, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 3.6, 3.6,
      3.6, 3.6, 4.2, 4.2, 4.2, 4.2, 3.6, 3.6, 3.6, 3.6, 4.2, 4.2, 4.2, 4.2, 3.6,
      3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6, 3.6 } ;

    lab2_DW.FromWorkspace_PWORK.TimePtr = (void *) pTimeValues0;
    lab2_DW.FromWorkspace_PWORK.DataPtr = (void *) pDataValues0;
    lab2_DW.FromWorkspace_IWORK.PrevIndex = 0;
  }

  /* Start for S-Function (sldrtao): '<Root>/Analog Output' */

  /* S-Function Block: <Root>/Analog Output */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE) lab2_P.AnalogOutput_RangeMode;
      parm.rangeidx = lab2_P.AnalogOutput_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1, &lab2_P.AnalogOutput_Channels,
                     &lab2_P.AnalogOutput_InitialValue, &parm);
    }
  }
}

/* Model terminate function */
void lab2_terminate(void)
{
  /* Terminate for S-Function (sldrtao): '<Root>/Analog Output' */

  /* S-Function Block: <Root>/Analog Output */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE) lab2_P.AnalogOutput_RangeMode;
      parm.rangeidx = lab2_P.AnalogOutput_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1, &lab2_P.AnalogOutput_Channels,
                     &lab2_P.AnalogOutput_FinalValue, &parm);
    }
  }
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/
void MdlOutputs(int_T tid)
{
  lab2_output();
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  lab2_update();
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  lab2_initialize();
}

void MdlTerminate(void)
{
  lab2_terminate();
}

/* Registration function */
RT_MODEL_lab2_T *lab2(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)lab2_M, 0,
                sizeof(RT_MODEL_lab2_T));

  /* Initialize timing info */
  {
    int_T *mdlTsMap = lab2_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    lab2_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    lab2_M->Timing.sampleTimes = (&lab2_M->Timing.sampleTimesArray[0]);
    lab2_M->Timing.offsetTimes = (&lab2_M->Timing.offsetTimesArray[0]);

    /* task periods */
    lab2_M->Timing.sampleTimes[0] = (0.0185);

    /* task offsets */
    lab2_M->Timing.offsetTimes[0] = (0.0);
  }

  rtmSetTPtr(lab2_M, &lab2_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = lab2_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    lab2_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(lab2_M, 4.995);
  lab2_M->Timing.stepSize0 = 0.0185;

  /* External mode info */
  lab2_M->Sizes.checksums[0] = (3262849084U);
  lab2_M->Sizes.checksums[1] = (3410108678U);
  lab2_M->Sizes.checksums[2] = (3202845322U);
  lab2_M->Sizes.checksums[3] = (1039253435U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[1];
    lab2_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(lab2_M->extModeInfo,
      &lab2_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(lab2_M->extModeInfo, lab2_M->Sizes.checksums);
    rteiSetTPtr(lab2_M->extModeInfo, rtmGetTPtr(lab2_M));
  }

  lab2_M->solverInfoPtr = (&lab2_M->solverInfo);
  lab2_M->Timing.stepSize = (0.0185);
  rtsiSetFixedStepSize(&lab2_M->solverInfo, 0.0185);
  rtsiSetSolverMode(&lab2_M->solverInfo, SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  lab2_M->blockIO = ((void *) &lab2_B);
  (void) memset(((void *) &lab2_B), 0,
                sizeof(B_lab2_T));

  /* parameters */
  lab2_M->defaultParam = ((real_T *)&lab2_P);

  /* states (dwork) */
  lab2_M->dwork = ((void *) &lab2_DW);
  (void) memset((void *)&lab2_DW, 0,
                sizeof(DW_lab2_T));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    lab2_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 14;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.PTransTable = &rtPTransTable;
  }

  /* Initialize Sizes */
  lab2_M->Sizes.numContStates = (0);   /* Number of continuous states */
  lab2_M->Sizes.numY = (0);            /* Number of model outputs */
  lab2_M->Sizes.numU = (0);            /* Number of model inputs */
  lab2_M->Sizes.sysDirFeedThru = (0);  /* The model is not direct feedthrough */
  lab2_M->Sizes.numSampTimes = (1);    /* Number of sample times */
  lab2_M->Sizes.numBlocks = (5);       /* Number of blocks */
  lab2_M->Sizes.numBlockIO = (2);      /* Number of block outputs */
  lab2_M->Sizes.numBlockPrms = (12);   /* Sum of parameter "widths" */
  return lab2_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
